package com.example.dfinal.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

/**
 * Created by MiguelÁngel on 5/14/2015.
 */
public class FinPartida {
    public void comprobarRecord(Context context,int puntuacion,int categoria){

        DBHelper admin2 = new DBHelper(context, "bdDSFinal", null, 1);
        SQLiteDatabase database2 = admin2.getWritableDatabase(); //Create and/or open a database that will be used for reading and writing.
        Cursor fila2 = database2.rawQuery("select * from puntuaciones ORDER BY aciertos DESC",null);
        int aux = fila2.getCount();
        if(aux<10){
            Intent i = new Intent(context, FinPartidaRecord.class);
            i.putExtra("puntuacion", puntuacion);
            i.putExtra("categoria", categoria);
            context.startActivity(i);
        }
       else {
            fila2.moveToLast();
            if(fila2.getInt(2) < puntuacion) {
                Intent i = new Intent(context, FinPartidaRecord.class);
                i.putExtra("puntuacion", puntuacion);
                i.putExtra("categoria", categoria);
                context.startActivity(i);
            }
            else{
                Intent j = new Intent(context, FinPartidaNoRecord.class);
                context.startActivity(j);
            }

        }
    }

}
