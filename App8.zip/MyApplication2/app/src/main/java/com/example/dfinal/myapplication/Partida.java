package com.example.dfinal.myapplication;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Timer;
import java.util.TimerTask;


public class Partida extends Activity {

    private Button resp1, resp2, resp3, resp4, mostrarElemento;
    TextView pregunta;
    private Cursor fila;
    int categoria;
    int preguntaActual;
    ArrayList<Pregunta> preguntas  = new ArrayList();
    int numAciertos, numFallos;
     MediaPlayer mp;
    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);

        mp= MediaPlayer.create(this, R.raw.obama);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("CATEGORIA");
            int aux = Integer.parseInt(value);
            categoria = aux;
        }
        numAciertos=0;
        numFallos=0;
        preguntaActual=0;
        setContentView(R.layout.activity_main);
        final ViewGroup viewGroup = (ViewGroup) ((ViewGroup) this
                .findViewById(android.R.id.content)).getChildAt(0);
        pregunta = (TextView) findViewById(R.id.Pregunta);
        resp1 = (Button) findViewById(R.id.respuesta1);
        resp2 = (Button) findViewById(R.id.respuesta2);
        resp3 = (Button) findViewById(R.id.respuesta3);
        resp4 = (Button) findViewById(R.id.respuesta4);
        mostrarElemento = (Button) findViewById(R.id.verImagenButton);

        DBHelper admin = new DBHelper(this,"bdDSFinal", null, 1);
        DBFill dbFill = new DBFill(admin);
        admin = dbFill.getDb();
        LectorPreguntas l = new LectorPreguntas();
        preguntas= l.importarPreguntas(this, categoria);
        resp1.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            comprobar(v);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );
        resp2.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            comprobar(v);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );
        resp3.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            comprobar(v);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );
        resp4.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            comprobar(v);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
        );



        siguiente(viewGroup);


    }



    public void comprobar(final View view) throws InterruptedException{
        String auxString;

        if(preguntas.get(preguntaActual).getRespuestas().get(0).getRespuesta().equals(((Button) findViewById(view.getId())).getText())){
            try {
                escucharSonido("acierto");
            } catch (IOException e) {
                e.printStackTrace();
            }
            numAciertos++;
            ((Button)findViewById(view.getId())).getBackground().setColorFilter(0xFF00FF00, PorterDuff.Mode.MULTIPLY);
        }else{
            try {
                escucharSonido("fallo");
            } catch (IOException e) {
                e.printStackTrace();
            }
            ((Button)findViewById(view.getId())).getBackground().setColorFilter(0xFFFF0000, PorterDuff.Mode.MULTIPLY);

            numFallos++;
        }
        resp1.setClickable(false);
        resp2.setClickable(false);
        resp3.setClickable(false);
        resp4.setClickable(false);
        final Handler handler = new Handler();
        Timer t = new Timer();
        t.schedule(new TimerTask() {
            public void run() {
                handler.post(new Runnable() {
                    public void run() {
                        preguntaActual++;
                        siguiente(view);
                    }
                });
            }
        }, 1000);
    }
    public void siguiente(View v)  {

        resp1.getBackground().clearColorFilter();
        resp2.getBackground().clearColorFilter();
        resp3.getBackground().clearColorFilter();
        resp4.getBackground().clearColorFilter();

        resp1.setClickable(true);
        resp2.setClickable(true);
        resp3.setClickable(true);
        resp4.setClickable(true);

        if(preguntaActual<10) {
            switch (preguntas.get(preguntaActual).getTipo()){
                case 0:
                    mostrarElemento.setVisibility(v.GONE);

                    break;
                case 1:
                    mostrarElemento.setText("Ver");
                    mostrarElemento.setOnClickListener(
                            new Button.OnClickListener() {
                                public void onClick(View v) {
                                    mostrarImagen();
                                }
                            }
                    );
                    mostrarElemento.setVisibility(v.VISIBLE);

                    break;
                case 2:
                    mostrarElemento.setText("Escuchar");
                    mostrarElemento.setOnClickListener(
                            new Button.OnClickListener() {
                                public void onClick(View v) {
                                    try {
                                        escucharSonido(preguntas.get(preguntaActual).getPath());
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                    );
                    mostrarElemento.setVisibility(v.VISIBLE);
                    break;
            }


            pregunta.setText(preguntas.get(preguntaActual).getPregunta());
            ArrayList<Respuesta> aux = new ArrayList<>(preguntas.get(preguntaActual).getRespuestas());
            Collections.shuffle(aux);

            resp1.setText(aux.get(0).getRespuesta());
            resp2.setText(aux.get(1).getRespuesta());
            resp3.setText(aux.get(2).getRespuesta());
            resp4.setText(aux.get(3).getRespuesta());
        }
        else{
            terminarPartida();
        }
    }

    public void mostrarImagen() {
        final Dialog settingsDialog = new Dialog(this);
        settingsDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        settingsDialog.setContentView(getLayoutInflater().inflate(R.layout.image_layout, null));
        ImageView image = (ImageView) settingsDialog.findViewById(R.id.dialog);
        image.setImageResource(this.getResources().getIdentifier(preguntas.get(preguntaActual).getPath(), "drawable", this.getPackageName()));
        image.setOnClickListener(new View.OnClickListener() {
            public void onClick(View View3) {
                settingsDialog.dismiss();
            }
        });
        settingsDialog.show();
    }

    private void escucharSonido(String sonido) throws IOException {
        int aux = this.getResources().getIdentifier(sonido, "raw", this.getPackageName());
       if(mp.isPlaying()){
           mp.stop();
       }
        mp.reset();
        mp= MediaPlayer.create(context, aux);
        mp.start();
    }

    private void terminarPartida() {

        FinPartida fp = new FinPartida();
        fp.comprobarRecord(context, numAciertos, categoria);

    }

}