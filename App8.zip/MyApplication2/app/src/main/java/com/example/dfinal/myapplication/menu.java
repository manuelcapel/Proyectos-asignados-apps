package com.example.dfinal.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;


public class menu extends Activity {

    private Button botonInicio, botonRecords, otros, salir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        botonInicio = (Button) findViewById(R.id.Start);
        otros = (Button) findViewById(R.id.otros);
        botonInicio.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                            loadActivity(v, 0);
                    }
                }
        );
        botonRecords = (Button) findViewById(R.id.records);
        botonRecords.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        loadActivity(v, 1);
                    }
                }
        );
        otros.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        loadActivity(v, 2);
                    }
                }
        );


    }


    private void loadActivity(View v, int opcion){

        switch(opcion){
            case 0:
                startActivity(new Intent(menu.this, SeleccionCategoria.class));
                break;
            case 1:
                startActivity(new Intent(menu.this, Records.class));
                break;
            case 2:
                Uri uri = Uri.parse("https://play.google.com/store/search?q=trivia");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
                break;

        }

    }

}
