package com.example.dfinal.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by MiguelÁngel on 5/14/2015.
 */
public class LectorPreguntas {

    public ArrayList<Pregunta> importarPreguntas(Context c, int categoria) {
        ArrayList<Pregunta> preguntas = new ArrayList<>();
        DBHelper admin = new DBHelper(c, "bdDSFinal", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase(); //Create and/or open a database that will be used for reading and writing.
        Cursor fila = bd.rawQuery(  //devuelve 0 o 1 fila //es una consulta
                "select * from preguntas where categoria =" + categoria+" order by RANDOM()", null);

        if (fila.moveToFirst()) {
            int indice = 0;
            boolean terminado = false;
            ArrayList<Respuesta> aux= new ArrayList<>();
            do{
                aux.add(new Respuesta(fila.getString(4), true));

                for(int i =5; i<8; i++){
                    aux.add(new Respuesta(fila.getString(i), false));
                }

                preguntas.add( new Pregunta(fila.getInt(0),fila.getInt(2),fila.getInt(1),fila.getString(3),aux,  fila.getString(8)));
                indice++;
                aux.clear();
            }while(indice<10&&fila.moveToNext());
        }
        return preguntas;
    }
}
