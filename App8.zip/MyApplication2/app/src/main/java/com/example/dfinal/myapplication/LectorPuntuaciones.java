package com.example.dfinal.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class LectorPuntuaciones {

    public ArrayList<Puntuacion> importarPuntuaciones(Context c) {
        ArrayList<Puntuacion> puntuaciones = new ArrayList<>();
        DBHelper admin = new DBHelper(c, "bdDSFinal", null, 1);
        SQLiteDatabase bd = admin.getWritableDatabase(); //Create and/or open a database that will be used for reading and writing.
        Cursor fila = bd.rawQuery(  //devuelve 0 o 1 fila //es una consulta
                "select * from puntuaciones", null);

        if (fila.moveToFirst()) {

            ArrayList<Puntuacion> aux= new ArrayList<>();
            do{
                puntuaciones.add( new Puntuacion(fila.getString(1),fila.getInt(2),fila.getInt(3)));
                aux.clear();
            }while(fila.moveToNext());
        }
        return puntuaciones;
    }
}
