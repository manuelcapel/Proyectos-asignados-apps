package com.example.dfinal.myapplication;

/**
 * Created by MiguelÁngel on 5/14/2015.
 */
public class Puntuacion {

    String nombre;
    int aciertos;
    int categoria;

    public Puntuacion(String n, int a, int c){
        nombre = n;
        aciertos = a;
        categoria =c;
    }

    public String getNombre(){
        return nombre;
    }
    public int getAciertos(){
        return aciertos;
    }
    public int getCategoría(){
        return categoria;
    }
}
