package com.example.dfinal.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class SeleccionCategoria extends Activity {

    Button deportes, geografia, historia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_seleccion_categoria);
        deportes = (Button) findViewById(R.id.deportes);
        deportes.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        startGame(v, 0);
                    }
                }
        );
        geografia = (Button) findViewById(R.id.geografia);
        geografia.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        startGame(v, 1);
                    }
                }
        );
        historia = (Button) findViewById(R.id.historia);
        historia.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {
                        startGame(v, 2);
                    }
                }
        );
    }

    private void startGame(View v, int categoria){
        Intent intent = new Intent(getBaseContext(), Partida.class);
        intent.putExtra("CATEGORIA", Integer.toString(categoria));
        startActivity(intent);
    }
}
