package com.example.dfinal.myapplication;

import android.database.Cursor;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by MiguelÁngel on 4/30/2015.
 */
public class Pregunta {
    private int id, tipo, categoria;
    private String pregunta,path;
    private ArrayList<Respuesta> respuestas= new ArrayList<>();

    public Pregunta(int id, int tipo,int categoria, String pregunta, ArrayList<Respuesta> respuestas, String path){
        this.id = id;
        this.tipo=tipo;
        this.categoria = categoria;
        this.pregunta = pregunta;
        this.respuestas = (ArrayList<Respuesta>)respuestas.clone();
        this.path=path;
    }

    public String getPregunta(){
        return pregunta;
    }

    public ArrayList<Respuesta> getRespuestas(){
       return respuestas;
   }

    public int getTipo(){
        return tipo;
    }

    public String getPath(){
        return path;
    }

}
