package com.example.dfinal.myapplication;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class FinPartidaRecord extends ActionBarActivity {
    private TextView resultado;
    private EditText nombreRecord;
    private Button boton;
    String nombre = "";

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_partida_record);
        DBHelper admin = new DBHelper(this, "bdDSFinal", null, 1);
        final SQLiteDatabase bd = admin.getWritableDatabase();
        final Cursor fila = bd.rawQuery(  //devuelve 0 o 1 fila //es una consulta
                "select * from puntuaciones", null);
        final int res = (int) getIntent().getExtras().getSerializable("puntuacion");
        final int categoria = (int) getIntent().getExtras().getSerializable("categoria");
        resultado = (TextView) findViewById(R.id.marcador);
        nombreRecord = (EditText) findViewById(R.id.introducirNombre);
        boton = (Button) findViewById(R.id.Confirmador);



        resultado.setText("Aciertos:  " + Integer.toString(res));

        boton.setOnClickListener(
            new Button.OnClickListener() {
                public void onClick(View v) {
                    nombre = nombreRecord.getText().toString();
                    ContentValues registro = new ContentValues();  //es una clase para guardar datos

                    registro.put("nombre", nombre);
                    registro.put("aciertos", res);
                    registro.put("categoria",categoria );

                    bd.insert("puntuaciones", null, registro);

                    String s[];
                    s = new String[1];
                    s[0] = "limit 1";

                    if (fila.getCount() == 10) {
                        if (fila.moveToLast()) {
                            bd.delete("puntuacion", "aciertos =" + fila.getInt(3), s);
                        }
                    }
                    loadRecords();
                }
            }
        );
    }

    private void loadRecords(){
        Intent j = new Intent(this, Records.class);
        startActivity(j);
    }
}
