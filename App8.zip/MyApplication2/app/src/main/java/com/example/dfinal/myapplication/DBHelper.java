package com.example.dfinal.myapplication;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    //llamamos al constructor
    public DBHelper(Context context, String nombre, CursorFactory factory, int version) {
        super(context, nombre, factory, version);
    }

    //creamos la tabla
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table preguntas(id integer primary key, categoria integer, tipo integer, pregunta text, respuestav text, respuestaf1 text, respuestaf2 text, respuestaf3 text, path text)");
        db.execSQL("create table puntuaciones(id integer primary key autoincrement ,nombre text, aciertos integer, categoria integer )");
    }

    //borrar la tabla y crear la nueva tabla
    @Override
    public void onUpgrade(SQLiteDatabase db, int versionAnte, int versionNue) {
        db.execSQL("drop table if exists preguntas");
        db.execSQL("create table preguntas(id integer primary key, categoria integer, tipo integer, pregunta text, respuestav text, respuestaf1 text, respuestaf2 text, respuestaf3 text, path text)");
        db.execSQL("drop table if exists puntuaciones");
        db.execSQL("create table puntuaciones(id integer primary key ,nombre text, aciertos integer, categoria integer )");
    }
}