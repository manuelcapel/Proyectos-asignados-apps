package com.example.dfinal.myapplication;

/**
 * Created by MiguelÁngel on 5/12/2015.
 */
public class Respuesta {

    String respuesta;
    boolean verdadera;

    Respuesta(String r, boolean v){
        respuesta=r;
        verdadera = v;
    }

    public String getRespuesta(){
        return respuesta;
    }

    public boolean getVeracidad(){
        return verdadera;
    }
}
