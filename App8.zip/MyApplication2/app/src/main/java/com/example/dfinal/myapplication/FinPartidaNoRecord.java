package com.example.dfinal.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class FinPartidaNoRecord extends ActionBarActivity {

    TextView categoria, aciertos, fallos;
    int punt, cat;
    Button continu;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_partida_no_record);
        categoria = (TextView) findViewById(R.id.categoria);
        aciertos = (TextView) findViewById(R.id.aciertos);
        fallos = (TextView) findViewById(R.id.fallos);
        continu = (Button) findViewById(R.id.continu);
        punt = (int) getIntent().getExtras().getSerializable("puntuacion");
        cat = (int) getIntent().getExtras().getSerializable("categoria");
        aciertos.setText("Aciertos:" + punt);
        fallos.setText("Fallos: " + (10-punt));

        continu.setOnClickListener(
                new Button.OnClickListener() {
                    public void onClick(View v) {

                        Intent j = new Intent(context, menu.class);
                        startActivity(j);

                    }
                });

    }
}
