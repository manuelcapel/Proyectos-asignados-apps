package com.example.dfinal.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class Records extends ActionBarActivity {


    ArrayList<Puntuacion> records= new ArrayList<>();
     LinearLayout layoutPrincipal;
    Context context = this;
    Button men;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);
        LectorPuntuaciones lp= new LectorPuntuaciones();
        records = lp.importarPuntuaciones(this);
        layoutPrincipal = (LinearLayout)findViewById(R.id.layoutPrincipal);
        men = (Button) findViewById(R.id.men);
        men.setOnClickListener(
           new Button.OnClickListener() {
            public void onClick(View v) {

                Intent j = new Intent(context, menu.class);
                startActivity(j);

            }
        });

       for(int i =0; i<records.size(); i++){
                addRow(records.get(i).getNombre(),records.get(i).getAciertos(), 10-records.get(i).getAciertos(), records.get(i).getCategoría());
        }
    }
    private void addRow(String nombre, int aciertos, int fallos, int categoria) {

        LinearLayout ll = new LinearLayout(this);
        TextView t = new TextView(this);
        t.setTextColor(Color.BLACK);
        t.setText(nombre);
        t.setLayoutParams(new TableLayout.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT, 0.25f));

        TextView t2 = new TextView(this);
        t2.setTextColor(Color.GREEN);
        t2.setText(Integer.toString(aciertos));
        t2.setLayoutParams(new TableLayout.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT, 0.25f));
        TextView t3 = new TextView(this);
        t3.setTextColor(Color.RED);
        t3.setText(Integer.toString(fallos));
        t3.setLayoutParams(new TableLayout.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT, 0.25f));
        TextView t4 = new TextView(this);
        t4.setTextColor(Color.BLACK);
        t4.setText(Integer.toString(categoria));
        t4.setLayoutParams(new TableLayout.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT, 0.25f));
        ll.addView(t);
        ll.addView(t2);
        ll.addView(t3);
        ll.addView(t4);

        layoutPrincipal.addView(ll);

    }

}
