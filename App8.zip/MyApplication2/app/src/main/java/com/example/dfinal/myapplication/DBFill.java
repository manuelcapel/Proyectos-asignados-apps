package com.example.dfinal.myapplication;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

/**
 * Created by MiguelÁngel on 4/30/2015.
 */
public class DBFill {
    DBHelper db;
    public DBFill(DBHelper dbhelper){
        db = dbhelper;
        fillTable();
    }

    private void fillTable() {
        /**
         * categorias
         *  0.-Deportes
         *  1.-Geografía
         *  2.-Historia
         */
        addQuestion(0,0,0, "¿Cuántos jugadores componen un equipo de futbol?", "11", "7", "10", "14","");
        addQuestion(1,0,0, "¿Cuántos jugadores componen un equipo de baloncesto?", "5", "7", "4", "6","");
        addQuestion(2,0,0, "¿Qué pelota es más pequeña?", "Ping-Pong", "Tenis", "Rugby", "Golf","");
        addQuestion(3,0,0, "¿Cuál es el equipo que ha ganado más veces la Champions League?", "R.Madrid", "Barcelona", "Juventus", "Manchester U.","");
        addQuestion(4,0,0, "¿En qué año se celebraron las olimpiadas en Barcelona?", "1992", "1996", "1988", "1984","");
        addQuestion(5,0,0, "¿Qué jugador de tenis tiene más Grand Slam?", "Federer", "Nadal", "Agasi", "Djokovick","");
        addQuestion(6,0,0, "¿Cuantos jugadores forman un equipo de volleyball?", "6", "5", "7", "11","");
        addQuestion(7,0,0, "¿Cuántos toques se pueden dar en una posesión en volleyball?", "3", "4", "2", "1","");
        addQuestion(8,0,0, "¿Cuántas disciplinas oficiales hay en natación?", "4", "5", "7", "3","");
        addQuestion(9,0,0, "¿Quien tiene el record del mundo de velocidad en 100m?", "Usain Bolt", "Mickey Mouse", "Tyson Gay", "Asafa Powell","");
        addQuestion(10,0,0, "¿Qué boxeador arrancó la oreja de un mordisco a su contrincante?", "Mike Tyson", "Floyd Mayweather", "Muhammad Ali", "Joe Frazier","");
        addQuestion(13,0,1, "¿Quien es el personaje de la foto?", "Zinedine Zidane", "Cristiano Ronaldo", "Roger Federer", "Raul Gonzalez","zidane");
        addQuestion(14,0,1, "¿Que es el objeto de la foto?", "Bate de cricket", "Raqueta de tenis", "Bate de beisbol","Balon de futbol","bate");
        addQuestion(15,0,1, "¿Que es el objeto de la foto?", "Ring de boxeo", "Campo de tenis", "Campo de beisbol","Salon de baile","cuadrilatero");
        addQuestion(16,0,1, "¿Que es el objeto de la foto?", "Balon de futbol americano", "Balon de balonpie", "Pelota de cricket","Balon de baloncesto","futbolamericano");

        addQuestion(17,0,2, "¿De que competicion es este Himno?", "Champions League", "Olimpiadas", "Campeonato de moto GP", "NBA","himnochampions");

        addQuestion(70,1,0, "¿Cual es la capital de España?", "Madrid","Barcelona", "Sevilla", "Granada","");
        addQuestion(71,1,0, "¿Cual es la capital de Australia?", "Camberra","Sidney", "Melbourne", "Brisbane","");
        addQuestion(72,1,0, "¿Cual es el lago mas Grande de Europa?", "Ladoga", "Ness", "Cobadonga", "Onega","");
        addQuestion(73,1,0, "¿Cual es el pico mas alto del mundo?", "Everest", "Montblanc", "Moncayo", "Teide","");
        addQuestion(74,1,0, "¿Cual es el rio mas largo de España?", "Ebro", "Tajo", "Genil", "Amazonas","");
        addQuestion(75,1,0, "¿Cuantos paises hay en Europa?", "49", "53", "30", "80","");
        addQuestion(76,1,0, "¿Cuantos paises hay en Africa?", "54", "28", "75", "80","");
        addQuestion(77,1,0, "¿Cual es la isla mas grande del mundo?", "Groenlandia", "Australia", "Gran Bretaña", "Madagascar","");
        addQuestion(78,1,0, "¿Cual es la capital de Holanda?", "Amsterdam", "Utrech", "La Haya", "Roterdam","");
        addQuestion(80,1,0, "¿Cual es el pais mas poblado del mundo?", "China", "India", "Estados Unidos", "Indonesia","");
        addQuestion(81,1,0, "¿Cual es el pais mas pequeño del mundo?", "Ciudad de Baticano", "Luxemburgo", "San marino", "Monaco","");

        addQuestion(82,1,1, "¿Como se llama este mar?", "Mar rojo", "Mar mediterraneo", "Mar de aral", "Mar caspio", "marrojo");
        addQuestion(83,1,1, "¿Como se llama esta comunidad Española?", "Andalucia", "Cataluña", "Madrid", "Murcia","andalucia");
        addQuestion(84,1,1, "¿Como se llama esta linea imaginaria?", "Ecuador", "Tropico de Cancer", "Tropico Capricornio", "Circulo Polar Artico","ecuador");


        addQuestion(86,1,2, "¿A que pais pertenece este himno?", "España", "Francia ", "Italia", "Holanda","himnosp");
        addQuestion(87,1,2, "¿A que pais pertenece este himno?", "Francia", "España ", "Italia", "EEUU","himnofr");
        addQuestion(88,1,2, "¿A que pais pertenece este himno?", "EEUU", "Francia ", "España", "Holanda","himnoeeu");

        addQuestion(35,2,0, "¿En que año acabo la II Guerra Mundial?", "1945","1950", "1975", "1930","");
        addQuestion(36,2,0, "¿En que año se reconquisto Granada?", "1492","1490", "1481", "1495","");
        addQuestion(37,2,0, "¿En que año se formo la Union Europea?", "1993","1992", "1990", "2000","");
        addQuestion(38,2,0, "¿En que ciudad estaba muro fue derribado en 1989?", "Berlin", "Madrid", "Londres", "Paris", "");
        addQuestion(39,2,0, "¿En que año fueron derribadas las Torres Gemelas?", "2001", "2000", "1989", "1994", "");
        addQuestion(41,2,0, "¿Cual fue el primer ordenador digital?", "Colossus", "Zespectrum", "Comodore", "iMac", "");
        addQuestion(42,2,0, "¿Quien descubrio America", "Cristobal Colon?", "Americo Vespucio", "Rihanna", "Willi Fog", "");
        addQuestion(43,2,0, "¿Cuando empieza el calendario gregoriano?", "Nacimiento de Cristo", "Muerte de Cristo", "Caida de Roma", "nacimiento Mahomma", "");
        addQuestion(44,2,0, "¿En que año termino la I Guerra Civil Española?", "1939", "1958", "1940", "1941", "");
        addQuestion(45,2,0, "¿En que año empezo la I Guerra Civil Española?", "1936", "1939", "1942", "1934", "");

        addQuestion(46,2,1, "¿Como se llama este Monumento?", "Alhambra", "Giralda", "Torre eifel", "Alcazar de Sevilla", "alhambra");
        addQuestion(47,2,1, "¿Quien pinto este cuadr?o", "Velazquez", "Goya", "Picasso", "Van gogh", "meninas");
        addQuestion(48,2,1, "¿Quien es el hombre de la foto?", "Ghandi", "Goya", "Picasso", "Van gogh", "ghandi");
        addQuestion(49,2,1, "¿En que pais se encuentra este monumento?", "Estados Unidos", "Francia", "Japon", "España", "rushmore");

        addQuestion(50,2,2, "¿Quien pronuncio este discurso?", "Martin Luther King", "Ghandi", "Rajoy", "Malcolm x","mlking");
        addQuestion(51,2,2, "¿Quien Presidente triundo con este slogan?", "Obama", "Aznar", "George Bush", "Angela Merkel","obama");

        ContentValues registro = new ContentValues();

        SQLiteDatabase bd = db.getWritableDatabase();


    }

    public DBHelper getDb(){
        return db;
    }

    private void addQuestion(int id,int categoria, int tipo, String pre, String rv, String rf1, String rf2, String rf3, String path) {
        SQLiteDatabase bd = db.getWritableDatabase();
        Cursor fila = bd.rawQuery("select * from preguntas where id=" + id, null);

        if(!fila.moveToFirst()) {  //devuelve true o false
            ContentValues registro = new ContentValues();  //es una clase para guardar datos
            registro.put("id", id);
            registro.put("categoria", categoria);
            registro.put("tipo", tipo);
            registro.put("pregunta", pre);
            registro.put("respuestav", rv);
            registro.put("respuestaf1", rf1);
            registro.put("respuestaf2", rf2);
            registro.put("respuestaf3", rf3);
            registro.put("path", path);
            bd.insert("preguntas", null, registro);
            bd.close();
        }
        else{
            bd.close();
        }
    }
}
