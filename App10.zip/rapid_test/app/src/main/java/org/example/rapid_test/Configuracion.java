package org.example.rapid_test;

import android.os.Bundle;
import android.preference.PreferenceActivity;

public class Configuracion extends PreferenceActivity {

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.configuracion);
    }
}