package org.example.rapid_test;

import java.util.Vector;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BaseDeDatos extends SQLiteOpenHelper{
		   //M�todos de SQLiteOpenHelper
		Context a;
		   public BaseDeDatos(Context context) {
		          super(context, "rapidTest", null, 1);
		          this.a=context;
		   }
		 
		   @Override
		   public void onCreate(SQLiteDatabase db) {
		          db.execSQL("CREATE TABLE puntuaciones ("+
		                       "_id INTEGER PRIMARY KEY AUTOINCREMENT, "+
		                       "puntos INTEGER, nombre TEXT, fecha LONG, tematica INTEGER)");
		          		          
		          db.execSQL("CREATE TABLE preguntas ("+
	                       "_id INTEGER PRIMARY KEY AUTOINCREMENT, "+
	                       "pregunta TEXT, respuesta1 TEXT, respuesta2 TEXT, respuesta3 TEXT, respuesta4 TEXT, correcta INTEGER, tematica INTEGER, id_pregunta INTEGER)");
		          
		          llenarBaseDeDatos(db);
		          
		   }
		 
		   @Override 
		   public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		   // En caso de una nueva version habra que actualizar las tablas
		   }
		 
		   //Metodos de AlmacenPuntuaciones
		   public void guardarPuntuacion(int puntos, String nombre, long fecha, int tematica) {
		          SQLiteDatabase db = getWritableDatabase();
		          db.execSQL("INSERT INTO puntuaciones VALUES ( null, "+puntos+", '"+nombre+"', "+fecha+", "+tematica+")");
		   }
		   
		   public Vector<String> listaPuntuaciones(int tematica) {
		          Vector<String> result = new Vector<String>();
		          SQLiteDatabase db = getReadableDatabase();
		          Cursor cursor;
		          if(tematica !=3){
		          	cursor = db.rawQuery("SELECT puntos, nombre FROM " + "puntuaciones where tematica="+tematica+" ORDER BY puntos DESC LIMIT 10", null);
		          }else{
		        	cursor = db.rawQuery("SELECT puntos, nombre FROM " + "puntuaciones ORDER BY puntos DESC LIMIT 10", null);
		          }
		          while (cursor.moveToNext()){
		                       result.add(cursor.getString(1)+" - "+cursor.getInt(0));
		          }
		          cursor.close();
		          return result;
		   }
		  
		 //Metodos de AlmacenPreguntas
		   public void guardarPreguntas(String pregunta, String respuesta1, String respuesta2, String respuesta3, String respuesta4, int correcta, int tematica, int id_pregunta){
		          SQLiteDatabase db = getWritableDatabase();
		          db.execSQL("INSERT INTO preguntas VALUES ( null, '"+pregunta+"', '"+respuesta1+"', '"+respuesta2+"', '"+respuesta3+"', '"+respuesta4+"', "+correcta+", "+tematica+", "+id_pregunta+")");
		   }
		   
		   public Vector<String> listaPreguntas(int tematica) {
		          Vector<String> result = new Vector<String>();
		          SQLiteDatabase db = getReadableDatabase();
		          Cursor cursor;
		          if(tematica !=4){
		        	  cursor = db.rawQuery("SELECT pregunta, respuesta1, respuesta2, respuesta3, respuesta4, correcta FROM " + "preguntas where tematica="+tematica, null);
		          }else{
		        	  cursor = db.rawQuery("SELECT pregunta, respuesta1, respuesta2, respuesta3, respuesta4, correcta FROM " + "preguntas ORDER BY id_pregunta ASC LIMIT 10", null);
		          }
		          while (cursor.moveToNext()){
		        	  result.add(cursor.getString(0)+";"+cursor.getString(1)+";"+cursor.getString(2)+";"+cursor.getString(3)+";"+cursor.getString(4)+";"+cursor.getInt(5));
		          }
		          cursor.close();
		          return result;
		   }
		   
		   private void llenarBaseDeDatos(SQLiteDatabase db){
			   for(int i=0;i<20;i++){
				   	String nombre = "Jugador "+i;
		        	  db.execSQL("INSERT INTO puntuaciones VALUES ( null, "+i*1000+", '"+nombre+"', "+i*1000000+(i%12*10000)+2013+", "+((i%2)+1)+")");
		       }

               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica10', 'Futbol', 'Tenis', 'Rugby', 'Karate', 1, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica11', 'Corinthians', 'Palmeiras', 'Cruzeiro', 'Sao Paulo', 1, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica12', 'Zlatan Ibrahimovic', 'Leo Messi', 'Cristiano Ronaldo', 'Arjen Robben', 3, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica13', 'Cinco', 'Cuatro', 'Seis', 'Uno', 2, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica14', 'Zinedine Zidane', 'Fernando Torres', 'Godin', 'Christian Vieri', 4, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica15', 'Ocho', 'Doce', 'Catorce', 'Cinco', 2, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica16', 'Inglaterra', 'Francia', 'Rusia', 'Estados Unidos', 4, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica17', 'Arrastre de piedra', 'Lanzamiento de fardo', 'Desintegramiento de piedra', 'Corte de troncos', 3, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica18', 'Vicente Calderon', 'Pizjuan', 'Bernabeu', 'Anoeta', 1, 1, 1)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica19', 'Madrid', 'Granada', 'Sevilla', 'Barcelona', 1, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica20', 'Kansas', 'Little Rock', 'Hot Springs','Washington', 2, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica21', 'Veranos secos y calurosos', 'Es un tipo de clima templado', 'Lluvias muy abundantes', 'Variables temperaturas en primavera', 3, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica22', 'Cinco', 'Tres', 'Cuatro', 'Dos', 1, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica23', 'Un muro', 'Nada', 'Un rio', 'Israel',4,2,2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica24', 'Nueva Zelanda', 'Chile', 'Argentina', 'Sudafrica', 3, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica25', 'Mauritania', 'Senegal', 'Gambia', 'Todos tienen',4, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica26', 'Mexico', 'Colombia', 'Chile', 'Cuba', 1, 2, 2)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica27', 'Mad Men', 'Shameless', 'Juego de Tronos', 'Downton Abbey', 1, 3, 3)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica28', '1941', '1943', '1942', '1940', 4, 3, 3)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica29', 'Chenoa', 'Ariana Grande', 'Laura Paussini', 'Tupac', 1, 3, 3)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica30', 'Sonny Montana', 'Tony Montana', 'Michael Corleone', 'Rajoy', 2, 3,3)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica31', 'Macaulay Culkin', 'Keanu Reeves', 'Leonardo DiCaprio', 'Johnny Depp', 1, 3,3)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica32', 'Jack Nicholson', 'Anthony Hopkins', 'Robert DeNiro', 'Ninguna es correcta', 1, 3,3)");
               db.execSQL("INSERT INTO preguntas VALUES ( null, 'preguntaTematica33', 'Lechuza', 'Sinsajo', 'Gale', 'Llamas', 2, 3,3)");
		   }
		   
}
