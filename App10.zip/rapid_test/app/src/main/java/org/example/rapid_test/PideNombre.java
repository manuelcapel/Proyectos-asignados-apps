package org.example.rapid_test;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class PideNombre extends Activity {

    /** Called when the activity is first created. */
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pidenombre);
        Button bAcept = (Button) findViewById(R.id.aceptar);
		bAcept.setOnClickListener(new OnClickListener() {
     	  		public void onClick(View view) {
     	  			EditText et = (EditText)findViewById(R.id.nombreJug);
     	  			RapidTest.bbdd.guardarPuntuacion(Juego.puntos, et.getText().toString(), Juego.tiempo, Juego.tematica);
     	  			finish();
     	  		}
       });
    }
}