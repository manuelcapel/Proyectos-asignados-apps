package org.example.rapid_test;

import java.util.Vector;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

public class JuegoPrincipal extends View{

	private int tematica;

    public JuegoPrincipal(Context context, AttributeSet attrs) {
          super(context, attrs);
          this.tematica=0;
          //jugarInicio();
    }

    @Override protected void onSizeChanged(int ancho, int alto, int ancho_anter, int alto_anter) {
          super.onSizeChanged(ancho, alto, ancho_anter, alto_anter);
    }

    @Override protected void onDraw(Canvas canvas) {
    }

    public void vistaJuegoResume(){
	}
    
    public void vistaJuegoPause(){
    }
    
    public void setTematica(int tematica)
    {
    	this.tematica=tematica;
    }
    
    public int getTematica(){

        return this.tematica;
    }
}