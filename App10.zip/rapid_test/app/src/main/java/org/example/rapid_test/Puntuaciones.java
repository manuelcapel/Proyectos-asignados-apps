package org.example.rapid_test;

import android.app.ListActivity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

public class Puntuaciones extends ListActivity {

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.puntuaciones);
        SharedPreferences gPuntos = getSharedPreferences("org.example.rapid_test_preferences", Context.MODE_PRIVATE);
        int tematica = Integer.parseInt(gPuntos.getString("tematica","1"));
        setListAdapter(new Apariencia(this, RapidTest.bbdd.listaPuntuaciones(tematica)));      
    }
}