LightQuiz
=========

Simple Quiz app for Android

question_generator.py is a python program to handle LightQuiz question generation

Features (planned):
* [X] Random Questions
* [X] Questions from external database (or file)
* [X] Sounds
* [ ] animations

This project is under Apache License 2
