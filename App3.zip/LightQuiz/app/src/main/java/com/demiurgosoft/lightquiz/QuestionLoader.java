package com.demiurgosoft.lightquiz;

public abstract class QuestionLoader {


    public abstract Question load();
    //   public abstract boolean isType();


}
