package com.demiurgosoft.lightquiz;


public class ImageQuestionLoader extends QuestionLoader {


    @Override
    public ImageQuestion load() {
        ImageQuestion question = new ImageQuestion();
        question.load();
        if (question.isValid()) return question;
        else return null;
    }

  /*  @Override
    public boolean isType(Cursor cursor) {
        String s;
        s = cursor.getString(cursor.getColumnIndex(imageColumn));
        return (s != null && !s.isEmpty());
    }*/
}
