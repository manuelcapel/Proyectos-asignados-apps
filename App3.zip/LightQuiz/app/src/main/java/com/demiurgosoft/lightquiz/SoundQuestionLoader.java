package com.demiurgosoft.lightquiz;

public class SoundQuestionLoader extends QuestionLoader {

    @Override
    public SoundQuestion load() {
        SoundQuestion question = new SoundQuestion();
        question.load();
        if (question.isValid()) return question;
        else return null;
    }

   /* @Override
    public boolean isType(Cursor cursor) {
        String s;
        s = cursor.getString(cursor.getColumnIndex(soundColumn));
        return (s != null && !s.isEmpty());
    }*/
}
