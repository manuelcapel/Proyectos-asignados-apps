package com.demiurgosoft.lightquiz;

import java.util.Random;

public enum QuestionType {
    TEXT, SOUND, IMAGE;

    public static QuestionType getRandomType() {
        Random rand = new Random();
        int selec = rand.nextInt(QuestionType.values().length);
        return QuestionType.values()[selec];
    }

}

