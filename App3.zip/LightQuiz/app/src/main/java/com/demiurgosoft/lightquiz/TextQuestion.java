package com.demiurgosoft.lightquiz;

public class TextQuestion extends Question {

    @Override
    public void load() {
        RawQuestion raw = questionList.getRawQuestion(type());
        if (raw != null) {
            loadText(raw);
            loadAnswers(raw);
        }
    }

    @Override
    public QuestionType type() {
        return QuestionType.TEXT;
    }

}
