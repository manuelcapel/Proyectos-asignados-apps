package ds.practica2.juegopreguntas.tipos;

/**
 * Created by bott1 on 24/04/2015.
 */
public enum TipoRespuestas {

    MULTIPLE, SIMPLE;
}
