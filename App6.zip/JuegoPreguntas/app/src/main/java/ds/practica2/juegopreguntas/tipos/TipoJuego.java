package ds.practica2.juegopreguntas.tipos;

/**
 * Created by bott1 on 14/04/2015.
 */
public enum TipoJuego {
    DEFAULT, NOT_GAME;
}
