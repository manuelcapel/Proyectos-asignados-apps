package ds.practica2.juegopreguntas.tipos;

/**
 * Created by bott1 on 14/04/2015.
 */
public enum TipoPregunta {
    TEXTO, IMAGEN, SONIDO, VIDEO, DEFAULT;
}
