package ds.practica2.juegopreguntas.preguntas;

/**
 * Created by bott1 on 16/04/2015.
 */
public enum CategoriaPregunta {
    CIENCIAS,
    CINE;
}
