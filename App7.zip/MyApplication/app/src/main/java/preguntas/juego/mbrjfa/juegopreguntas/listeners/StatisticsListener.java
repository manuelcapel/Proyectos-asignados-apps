package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.content.Intent;
import android.view.View;

import java.util.ArrayList;

import preguntas.juego.mbrjfa.juegopreguntas.Principal;
import preguntas.juego.mbrjfa.juegopreguntas.QuizzData;
import preguntas.juego.mbrjfa.juegopreguntas.Statistics;

/**
 * Created by sonyk on 10/05/2015.
 */
public class StatisticsListener implements View.OnClickListener {
    private Principal activity;

    public StatisticsListener(Principal activity){
        this.activity = activity;
    }

    @Override
    public void onClick(View v) {
        ArrayList<QuizzData> resultados = activity.getResults();
        Intent intent = new Intent(activity, Statistics.class);
        intent.putExtra("Intent", "Statistics");

        if(resultados != null) {
            intent.putExtra("numQuizz", resultados.size());
            for (int i = 0; i < resultados.size(); ++i) {
                intent.putStringArrayListExtra("Questions" + i, resultados.get(i).getQuestions());
                intent.putStringArrayListExtra("Answers" + i, resultados.get(i).getAnswers());
                intent.putStringArrayListExtra("UserAnswers" + i, resultados.get(i).getUserAnswers());
            }
        }
            activity.startActivity(intent);
    }
}
