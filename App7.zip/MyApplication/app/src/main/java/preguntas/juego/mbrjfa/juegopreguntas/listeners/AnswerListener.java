package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import Model.DatosPregunta;
import preguntas.juego.mbrjfa.juegopreguntas.Cuestionario;
import preguntas.juego.mbrjfa.juegopreguntas.R;

/**
 * Created by sonyk on 12/05/2015.
 */
public class AnswerListener implements View.OnClickListener {
    Cuestionario activity;
    private MediaPlayer correctSound;
    private MediaPlayer errorSound;

    public AnswerListener(Cuestionario activity){
        this.activity = activity;

        correctSound = MediaPlayer.create(activity, R.raw.correcto);
        errorSound = MediaPlayer.create(activity, R.raw.mal);

        correctSound.setAudioStreamType(AudioManager.STREAM_MUSIC);
        errorSound.setAudioStreamType(AudioManager.STREAM_MUSIC);
    }

    @Override
    public void onClick(View v) {
        Button button = (Button)v;
        DatosPregunta pregunta = activity.getPregunta();
        ArrayList<DatosPregunta> visitados = activity.getVisitados();
        visitados.add(pregunta);

        pregunta.setRespuestaElegida((String) button.getText());
        activity.getEstadisticas().add(pregunta);

        if( ((String) button.getText()).compareTo(pregunta.getRespuestaCorrecta()) == 0 ) {
            TextView textoPregunta = activity.getTextoPregunta();
            textoPregunta.setText("¡Acierto!");
            textoPregunta.setTextColor(Color.GREEN);
            textoPregunta.setTextSize(30);

            playSound("Correcto");

            textoPregunta.setTextSize(20);
            textoPregunta.setTextColor(Color.BLACK);
            if (activity.getNumPreguntaActual() < 5) {
                //Se deben esperar unos segundos antes de ésto.
                while (visitados.contains(pregunta) || pregunta.getTextoPregunta().equals("")) {
                    pregunta = activity.getNextQuestion();
                }
                activity.estableceLayout(pregunta.getTipoContenido());
                //activity.colocaTextoCampos();
                activity.increaseCurrentQuestion();
                }else{
                    llamaFinal();
                }
        }else{
            playSound("Mal");
            DatosPregunta backup = pregunta;
            if (activity.getNumPreguntaActual() < 5) {
                //Se deben esperar unos segundos antes de ésto.
                while (visitados.contains(pregunta) || pregunta.getTextoPregunta().equals("")) {
                    pregunta = activity.getNextQuestion();
                }
                activity.increaseCurrentQuestion();
                llamaPopUp(backup);
            }else{
                llamaFinal();
                //llamar a actividad resultado final y parar ésta.
            }
        }
    }

    public void llamaPopUp(DatosPregunta pregunta){
        activity.setContentView(R.layout.activity_pop_up_error);

        final TextView alertaTexto = (TextView)activity.findViewById(R.id.alerta);
        alertaTexto.setText(R.string.error);

        Button volver = (Button)activity.findViewById(R.id.volver);
        Button continuar = (Button)activity.findViewById(R.id.seguir);

        abrePopError(pregunta);
        //Listener para saber lo que se ha elegido.
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finishActivity();
            }

        });

        continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.setContentView(R.layout.activity_cuestionario);
                activity.actualizaTextoCampos();
            }
        });
    }

    public void llamaFinal(){
        activity.setContentView(R.layout.activity_final_juego);
        TextView tituloFin = (TextView) activity.findViewById(R.id.titulo);
        TextView respuestasFin = (TextView) activity.findViewById(R.id.respuestas);
        TextView felicitacion = (TextView) activity.findViewById(R.id.felicitacion);

        tituloFin.setText("Las respuestas:");
        ArrayList<DatosPregunta> estadisticas = activity.getEstadisticas();
        respuestasFin.setText(estadisticas.get(0).getTextoPregunta()+": \n"+"\t"+estadisticas.get(0).getRespuestaCorrecta()+"\n\n"+
                estadisticas.get(1).getTextoPregunta()+": \n"+"\t"+estadisticas.get(1).getRespuestaCorrecta()+"\n\n"+
                estadisticas.get(2).getTextoPregunta()+": \n"+"\t"+estadisticas.get(2).getRespuestaCorrecta()+"\n\n"+
                estadisticas.get(3).getTextoPregunta()+": \n"+"\t"+estadisticas.get(3).getRespuestaCorrecta()+"\n\n"+
                estadisticas.get(4).getTextoPregunta()+": \n"+"\t"+estadisticas.get(4).getRespuestaCorrecta());
        felicitacion.setText("¡Felicidades has terminado!");
        Button inicio = (Button) activity.findViewById(R.id.Inicio);
        inicio.setText("Inicio");

        inicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retornaEstadisticas();
            }
        });
    }

    public void playSound(String resource){
        if(resource.equals("Correcto")) {
            correctSound.start();
        }else{
            errorSound.start();
        }
    }

    public void retornaEstadisticas(){
        ArrayList<DatosPregunta> estadisticas = activity.getEstadisticas();
        Intent intent = activity.getIntent();
        intent.putExtra("numElements", estadisticas.size());
        for(int i=0; i<estadisticas.size(); ++i){
            intent.putExtra("Question"+i, estadisticas.get(i).getTextoPregunta());
            intent.putExtra("Answer"+i, estadisticas.get(i).getRespuestaCorrecta());
            intent.putExtra("UserAnswer"+i, estadisticas.get(i).getRespuestaElegida());
        }
        activity.setResult(Activity.RESULT_OK, intent);
        activity.finishActivity();
    }

    public void abrePopError(DatosPregunta pregunta){
        TextView tituloPop = (TextView) activity.findViewById(R.id.tituloRespuesta);
        TextView respuestaPop = (TextView) activity.findViewById(R.id.respuestaCorrecta);
        tituloPop.setText(R.string.answer);
        respuestaPop.setText(pregunta.getRespuestaCorrecta());
    }
}
