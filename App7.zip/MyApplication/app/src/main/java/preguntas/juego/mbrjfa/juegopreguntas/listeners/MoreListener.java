package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.content.Intent;
import android.view.View;

import preguntas.juego.mbrjfa.juegopreguntas.MoreGames;
import preguntas.juego.mbrjfa.juegopreguntas.Principal;

/**
 * Created by sonyk on 10/05/2015.
 */
public class MoreListener implements View.OnClickListener {
    private Principal activity;

    public MoreListener(Principal activity){
        this.activity = activity;
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(activity, MoreGames.class);
        intent.putExtra("Intent", "More Games");
        activity.startActivity(intent);
    }
}
