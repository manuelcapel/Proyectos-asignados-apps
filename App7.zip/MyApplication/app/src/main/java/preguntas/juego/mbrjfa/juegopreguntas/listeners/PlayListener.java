package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.app.Activity;
import android.util.Log;
import android.view.View;

import preguntas.juego.mbrjfa.juegopreguntas.Principal;
import preguntas.juego.mbrjfa.juegopreguntas.R;

/**
 * Created by sonyk on 10/05/2015.
 */
public class PlayListener implements View.OnClickListener {
    private Principal activity;

    public PlayListener(Principal principal){
        this.activity = principal;
    }

    @Override
    public void onClick(View v) {
        activity.setContentView(R.layout.jugar);
        Principal.setStatus("jugar");
        activity.jugar();
    }
}
