package preguntas.juego.mbrjfa.juegopreguntas;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

import Model.DatosPregunta;

/**
 * Created by sonyk on 12/05/2015.
 */
public class QuizzData{
    private ArrayList<String> questions;
    private ArrayList<String> answers;
    private ArrayList<String> userAnswers;

    public QuizzData(){
        questions = new ArrayList<String>();
        answers = new ArrayList<String>();
        userAnswers = new ArrayList<String>();
    }

    public QuizzData(ArrayList<String> questions, ArrayList<String> answers, ArrayList<String> userAnswers){
        this.questions = questions;
        this.answers = answers;
        this.userAnswers = userAnswers;
    }

    public void pushQuestion(String question, String answer, String userAnswer){
        questions.add(question);
        answers.add(answer);
        userAnswers.add(userAnswer);
    }

    public ArrayList<String> getQuestions(){
        return questions;
    }

    public ArrayList<String> getAnswers(){
        return answers;
    }

    public ArrayList<String> getUserAnswers(){
        return userAnswers;
    }
}
