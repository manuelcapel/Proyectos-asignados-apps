package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.View;

import preguntas.juego.mbrjfa.juegopreguntas.Principal;
import preguntas.juego.mbrjfa.juegopreguntas.R;

/**
 * Created by Manuel on 12/05/2015.
 */
public class SoundListener implements View.OnClickListener {
    private Activity activity;
    int sound;

    public SoundListener(Activity actividad, int sonido){
        activity = actividad;
        sound = sonido;
    }

    @Override
    public void onClick(View v) {
        MediaPlayer mMediaPlayer = new MediaPlayer();
        mMediaPlayer = MediaPlayer.create(activity, sound);
        mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mMediaPlayer.start();
    }
}