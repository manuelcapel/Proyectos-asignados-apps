package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import preguntas.juego.mbrjfa.juegopreguntas.Principal;
import preguntas.juego.mbrjfa.juegopreguntas.QuizzData;
import preguntas.juego.mbrjfa.juegopreguntas.R;
import preguntas.juego.mbrjfa.juegopreguntas.Statistics;

/**
 * Created by sonyk on 11/05/2015.
 */
public class ResultListener implements View.OnClickListener {
    private Statistics activity;
    private QuizzData cuestionario;

    public ResultListener(Statistics activity, QuizzData cuestionario){
        this.activity = activity;
        this.cuestionario = cuestionario;
    }

    @Override
    public void onClick(View v) {
        activity.setContentView(R.layout.resultado_cuestionario);
        Statistics.setStatus("Cuestionario");

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        LinearLayout.LayoutParams layParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        LinearLayout layout = (LinearLayout)activity.findViewById(R.id.resultadoCuestionario);



        for(int i=0; i<cuestionario.getQuestions().size(); ++i){
            LinearLayout bitLayout = new LinearLayout(activity);
            bitLayout.setBackground(activity.getResources().getDrawable(R.drawable.square));
            bitLayout.setOrientation(LinearLayout.VERTICAL);
            bitLayout.setPadding(10, 10, 10, 5);


            TextView pregunta = new TextView(activity);
            TextView respuesta = new TextView(activity);
            TextView respuestaUsuario = new TextView(activity);

            int size = 25;
            pregunta.setText("Pregunta: " + cuestionario.getQuestions().get(i));
            pregunta.setTextSize(size);
            respuesta.setText("Respuesta correcta: " + cuestionario.getAnswers().get(i));
            respuesta.setTextSize(size);
            respuestaUsuario.setText("Tu respuesta ha sido: " + cuestionario.getUserAnswers().get(i));
            respuestaUsuario.setTextSize(size);

            bitLayout.addView(pregunta, params);
            bitLayout.addView(respuesta, params);
            bitLayout.addView(respuestaUsuario, params);

            layout.addView(bitLayout, layParams);
        }
    }
}
