package preguntas.juego.mbrjfa.juegopreguntas;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import Model.DatosPregunta;
import Model.FactoriaCuestionario.FactoriaCienciaTecnologia;
import Model.FactoriaCuestionario.FactoriaCine;
import Model.FactoriaCuestionario.FactoriaCuestionario;
import Model.FactoriaCuestionario.FactoriaDeporte;
import Model.FactoriaCuestionario.FactoriaSalud;

import preguntas.juego.mbrjfa.juegopreguntas.listeners.AnswerListener;
import preguntas.juego.mbrjfa.juegopreguntas.listeners.SoundListener;


public class Cuestionario extends AppCompatActivity {
    //Botón con el texto de la pregunta.
    TextView textoPregunta;
    TextView textoCuestionario;
    //Botones de respuestas.
    Button respuesta1;
    Button respuesta2;
    Button respuesta3;
    Button respuesta4;
    //Pregunta que se va obteniendo en tiempo de ejecución.
    DatosPregunta pregunta;
    ArrayList<DatosPregunta> estadisticas;
    int numPreguntaActual = 0;
    View.OnClickListener yourClickListener;
    final ArrayList<DatosPregunta> visitados = new ArrayList<>();

    Model.FactoriaCuestionario.Cuestionario cuestionario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);

        estadisticas = new ArrayList<>();
        String tipoCuestionario = getIntent().getStringExtra("Cuestionario");
        cuestionario = obtieneTipoCuestionario(tipoCuestionario);
        pregunta = cuestionario.getPregunta().extraePregunta();


        visitados.add(pregunta);
        numPreguntaActual++;

        yourClickListener = new AnswerListener(this);
        estableceLayout(pregunta.getTipoContenido());
    }

    public void estableceLayout(String tipoContenido){
        switch(tipoContenido){
            case "Sonido":  setContentView(R.layout.activity_cuestionario_sound);
                            colocaSonidoCampos();
                            break;
            case "Imagen": setContentView(R.layout.activity_cuestionario_img);
                            colocaImagenCampos();
                            break;
            case "Texto":   setContentView(R.layout.activity_cuestionario);
                            actualizaTextoCampos();
                            break;
        }
    }

    public void colocaTextoCampos(){
        int size = 25;
        textoCuestionario = (TextView) findViewById(R.id.temaCuestionario);
        textoCuestionario.setText(getIntent().getStringExtra("Cuestionario"));
        textoCuestionario.setTextSize(40);

        textoPregunta.setText(pregunta.getTextoPregunta());
        respuesta1.setText(pregunta.getRespuestas().get(0));
        respuesta1.setTextSize(size);
        respuesta2.setText(pregunta.getRespuestas().get(1));
        respuesta2.setTextSize(size);
        respuesta3.setText(pregunta.getRespuestas().get(2));
        respuesta3.setTextSize(size);
        respuesta4.setText(pregunta.getRespuestas().get(3));
        respuesta4.setTextSize(size);
    }

    public void colocaSonidoCampos(){
        actualizaTextoCampos();
        ImageButton altavoz = (ImageButton) findViewById(R.id.sonido);
        SoundListener sndl = new SoundListener(this,Integer.parseInt(pregunta.getRecurso()));
        altavoz.setOnClickListener(sndl);
    }

    public void colocaImagenCampos(){
        actualizaTextoCampos();
        ImageView imgv = (ImageView) findViewById(R.id.imagen);
        imgv.setImageResource(Integer.parseInt(pregunta.getRecurso()));
    }

    public void setListenersBotones(View.OnClickListener yourClickListener){
        respuesta1.setOnClickListener(yourClickListener);
        respuesta2.setOnClickListener(yourClickListener);
        respuesta3.setOnClickListener(yourClickListener);
        respuesta4.setOnClickListener(yourClickListener);
    }

    public void actualizaTextoCampos(){
        textoPregunta = (TextView) this.findViewById(R.id.textoPregunta);
        respuesta1 = (Button) this.findViewById(R.id.respuesta1);
        respuesta2 = (Button) this.findViewById(R.id.respuesta2);
        respuesta3 = (Button) this.findViewById(R.id.respuesta3);
        respuesta4 = (Button) this.findViewById(R.id.respuesta4);

        colocaTextoCampos();
        setListenersBotones(yourClickListener);
    }

    public Model.FactoriaCuestionario.Cuestionario obtieneTipoCuestionario(String tipoCuestionario){
        Model.FactoriaCuestionario.Cuestionario cuestionario = null;
        FactoriaCuestionario fd;

        switch(tipoCuestionario){
            case "Deportes": fd = new FactoriaDeporte();
                            cuestionario = fd.crearInstancia();
                            break;
            case "Salud": fd = new FactoriaSalud();
                        cuestionario = fd.crearInstancia();
                        break;
            case "CienciaTecnologia": fd = new FactoriaCienciaTecnologia();
                            cuestionario = fd.crearInstancia();
                            break;
            case "Cine": fd = new FactoriaCine();
                        cuestionario = fd.crearInstancia();
                        break;
            default:
                Log.d("debug","Error en el tipo de cuestionario especificado");
                break;
        }
        return cuestionario;
    }

    public ArrayList<DatosPregunta> getVisitados(){
        return visitados;
    }

    public DatosPregunta getPregunta(){
        return pregunta;
    }

    public ArrayList<DatosPregunta> getEstadisticas(){
        return estadisticas;
    }

    public TextView getTextoPregunta(){
        return textoPregunta;
    }

    public int getNumPreguntaActual(){
        return numPreguntaActual;
    }

    public DatosPregunta getNextQuestion(){
        pregunta = cuestionario.getPregunta().extraePregunta();
        return pregunta;
    }

    public void increaseCurrentQuestion(){
        numPreguntaActual++;
    }

    public void finishActivity(){
        finish();
    }

}
