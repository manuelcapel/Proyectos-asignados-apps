package preguntas.juego.mbrjfa.juegopreguntas;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import java.util.ArrayList;

import Model.DatosPregunta;
import preguntas.juego.mbrjfa.juegopreguntas.listeners.CuestionarioListener;
import preguntas.juego.mbrjfa.juegopreguntas.listeners.MoreListener;
import preguntas.juego.mbrjfa.juegopreguntas.listeners.PlayListener;
import preguntas.juego.mbrjfa.juegopreguntas.listeners.StatisticsListener;


public class Principal extends AppCompatActivity {
    private static String status = "principal";
    private View.OnClickListener playListener, statisticsListener, moreListener;
    public static final int REQUEST_ID = 1234;
    ArrayList<QuizzData> resultadosCuestionarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        //Creacion de la Base de Datos
        DBHelper dbHelper = new DBHelper(this.getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String[] campos = new String[] {"Pregunta","rCorrecta" ,"rIncorrecta1","rIncorrecta2","rIncorrecta3","ID","tematica","tipoContenido","recurso"};
        Cursor c = db.query("Cuestionarios", campos, null, null, null, null, null);

        ArrayList<DatosPregunta> datosPregunta = new ArrayList<>();
        if (c.moveToFirst()) {
            //Recorremos el cursor hasta que no haya mas registros
            do {
                DatosPregunta dp = new DatosPregunta(c.getString(0),c.getString(1),c.getString(2),
                        c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),
                        c.getString(8));
                datosPregunta.add(dp);
            } while(c.moveToNext());
        }
        c.close();
        Model.FactoriaCuestionario.Cuestionario.setPreguntasTotales(datosPregunta);
        Log.i("debug", ((Integer) R.raw.ola).toString());

        resultadosCuestionarios = new ArrayList<QuizzData>();
        playListener = new PlayListener(this);
        statisticsListener = new StatisticsListener(this);
        moreListener = new MoreListener(this);

        setListeners();
    }

    private void setListeners(){
        Button play = (Button)findViewById(R.id.play);
        Button statistics = (Button)findViewById(R.id.statistics);
        Button more = (Button)findViewById(R.id.more);

        play.setOnClickListener( playListener );
        statistics.setOnClickListener( statisticsListener );
        more.setOnClickListener( moreListener );
    }

    @Override
    public void onBackPressed() {
        if(Principal.getStatus().equals("principal"))
            super.onBackPressed();
        else {
            Principal.setStatus("principal");
            setContentView(R.layout.activity_principal);
            setListeners();
        }
    }

    public void jugar(){

        //Obtener de la base de datos los tipos de cuestionarios que hay y meterlos aquí.
        Button deportes = (Button)findViewById(R.id.deportes);
        Button salud = (Button)findViewById(R.id.salud);
        Button cine = (Button)findViewById(R.id.cine);
        Button ciencia = (Button)findViewById(R.id.ciencia);

        deportes.setOnClickListener(new CuestionarioListener(this, "Deportes"));
        salud.setOnClickListener(new CuestionarioListener(this, "Salud"));
        cine.setOnClickListener(new CuestionarioListener(this, "Cine"));
        ciencia.setOnClickListener(new CuestionarioListener(this, "CienciaTecnologia"));
    }

    public static String getStatus(){
        return Principal.status;
    }

    public static void setStatus(String state){
        Principal.status = state;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ID) {
            if (resultCode == RESULT_OK) {
                Principal.setStatus("principal");
                setContentView(R.layout.activity_principal);
                setListeners();
                int numElems = data.getIntExtra("numElements", -1);
                if(numElems > 0){
                    QuizzData quizz = new QuizzData();
                    String question;
                    String answer;
                    String userAnswer;
                    for(int i=0; i<numElems; ++i){
                        question = data.getStringExtra("Question"+i);
                        answer = data.getStringExtra("Answer"+i);
                        userAnswer = data.getStringExtra("UserAnswer"+i);
                        quizz.pushQuestion(question, answer, userAnswer);
                    }
                    resultadosCuestionarios.add(quizz);
                }
            }
        }
    }

    public ArrayList<QuizzData> getResults(){
        return resultadosCuestionarios;
    }
}
