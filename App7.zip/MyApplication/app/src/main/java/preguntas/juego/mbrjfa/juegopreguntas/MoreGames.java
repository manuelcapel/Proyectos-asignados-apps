package preguntas.juego.mbrjfa.juegopreguntas;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;

import preguntas.juego.mbrjfa.juegopreguntas.listeners.OtherGameListener;

/**
 * Created by okynos on 10/05/15.
 */
public class MoreGames extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_games);

        ImageButton game1 = (ImageButton)findViewById(R.id.game1);
        ImageButton game2 = (ImageButton)findViewById(R.id.game2);
        ImageButton game3 = (ImageButton)findViewById(R.id.game3);
        ImageButton game4 = (ImageButton)findViewById(R.id.game4);

        game1.setOnClickListener(new OtherGameListener(this,
                "https://play.google.com/store/apps/details?id=com.prettysimple.criminalcaseandroid"));
        game2.setOnClickListener(new OtherGameListener(this,
                "https://play.google.com/store/apps/details?id=com.netmarble.mherosgb"));
        game3.setOnClickListener(new OtherGameListener(this,
                "https://play.google.com/store/apps/details?id=com.victorkunai.Me_comi_una_salchipapa"));
        game4.setOnClickListener(new OtherGameListener(this,
                "https://play.google.com/store/apps/details?id=com.ea.game.easportsufc_row"));
    }
}
