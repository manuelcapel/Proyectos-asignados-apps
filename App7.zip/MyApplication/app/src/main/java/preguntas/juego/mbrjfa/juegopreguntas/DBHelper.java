package preguntas.juego.mbrjfa.juegopreguntas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.Scanner;


public class DBHelper extends SQLiteOpenHelper {

    public static final int VERSION_DB = 1;
    public static final String NOMBRE_BD = "database13.db";
    public static  Context mContext= null;

    public DBHelper(){
        super(mContext,NOMBRE_BD, null, VERSION_DB);

    }

    public DBHelper(Context context) {
        super(context, NOMBRE_BD, null, VERSION_DB);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("debug", "Creando la Base de Datos");

        StringBuilder sb = new StringBuilder();
        Scanner sc = new Scanner(this.mContext.getResources().openRawResource(R.raw.database));
        while(sc.hasNextLine()) {
            sb.append(sc.nextLine());
            sb.append('\n');
            if (sb.indexOf(";") != -1) {
                db.execSQL(sb.toString());
                sb.delete(0, sb.capacity());
            }
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
