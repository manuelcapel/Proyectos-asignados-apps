package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.content.Intent;
import android.view.View;

import preguntas.juego.mbrjfa.juegopreguntas.Cuestionario;
import preguntas.juego.mbrjfa.juegopreguntas.Principal;
import preguntas.juego.mbrjfa.juegopreguntas.Statistics;
import preguntas.juego.mbrjfa.juegopreguntas.util.SystemUiHider;

/**
 * Created by sonyk on 10/05/2015.
 */
public class CuestionarioListener implements View.OnClickListener {
    private Principal activity;
    private String kind;

    public CuestionarioListener(Principal activity, String kind){
        this.activity = activity;
        this.kind = kind;
    }

    @Override
    public void onClick(View v) {
        //Llamar a la activity cuestionarios con el parámetro que se ha escojido
        Intent intent = new Intent(activity, Cuestionario.class);
        intent.putExtra("Cuestionario", kind);
        activity.startActivityForResult(intent, Principal.REQUEST_ID);
    }
}
