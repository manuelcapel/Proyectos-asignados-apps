package preguntas.juego.mbrjfa.juegopreguntas.listeners;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

import preguntas.juego.mbrjfa.juegopreguntas.MoreGames;

/**
 * Created by sonyk on 12/05/2015.
 */
public class OtherGameListener implements View.OnClickListener {
    private MoreGames activity;
    private String url;

    public OtherGameListener(MoreGames activity, String url){
        this.activity = activity;
        this.url = url;
    }

    @Override
    public void onClick(View v) {
        Uri uri = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        activity.startActivity(intent);
    }
}
