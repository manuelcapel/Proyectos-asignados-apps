package preguntas.juego.mbrjfa.juegopreguntas;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import java.util.ArrayList;

import preguntas.juego.mbrjfa.juegopreguntas.listeners.ResultListener;

/**
 * Created by sonyk on 10/05/2015.
 */
public class Statistics extends AppCompatActivity {
    private ArrayList<QuizzData> resultados;
    private static String status = "estadísticas";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estadisticas);
        resultados = new ArrayList<QuizzData>();

        Intent intent = getIntent();
        int numQuizz = intent.getIntExtra("numQuizz", -1);
        if(numQuizz > 0){
            for(int i=0; i<numQuizz; ++i){
                ArrayList<String> questions = intent.getStringArrayListExtra("Questions" + i);
                ArrayList<String> answers = intent.getStringArrayListExtra("Answers" + i);
                ArrayList<String> userAnswers = intent.getStringArrayListExtra("UserAnswers" + i);
                QuizzData quizz = new QuizzData(questions, answers, userAnswers);
                resultados.add(quizz);
            }
        }

        setStatisticsScreen();
    }

    public void setStatisticsScreen(){
        LinearLayout layout = (LinearLayout)findViewById(R.id.buttonslayout);
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        Drawable background;

        if(resultados.size() == 0){
            background = getResources().getDrawable(R.drawable.square);
            TextView empty = new TextView(this);
            empty.setText(R.string.emptystatistics);
            empty.setTextSize(40);
            empty.setBackground(background);
            empty.setPadding(10, 1, 10, 1);
            layout.addView(empty, params);

        }else {
            for (int i = 0; i < resultados.size(); ++i) {
                background = getResources().getDrawable(R.drawable.button_custom);
                Button boton = new Button(this);
                boton.setText("Cuestionario " + (i+1));
                boton.setBackground(background);
                ResultListener listener = new ResultListener(this, resultados.get(i));
                boton.setOnClickListener(listener);

                layout.addView(boton, params);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if(Statistics.getStatus().equals("estadísticas"))
            super.onBackPressed();
        else{
            Statistics.setStatus("estadísticas");
            setContentView(R.layout.activity_estadisticas);
            setStatisticsScreen();
        }
    }

    public static String getStatus(){
        return Statistics.status;
    }

    public static void setStatus(String state){
        Statistics.status = state;
    }
}
