package Model;

import java.util.ArrayList;

/**
 * Created by Manuel on 07/05/2015.
 */
public class DatosPregunta {
    private String pregunta;
    private String rCorrecta;
    private String tematica;
    private String tipoContenido;
    private ArrayList<String> respuestas;
    private String ID;
    private String respuestaElegida;
    String recurso;

    public DatosPregunta(String pregunta, String rcorrecta, String rincorrecta1,String rincorrecta2,String rincorrecta3,String ID, String tematica, String tipoContenido, String recurso){
        this.pregunta = pregunta;
        respuestas = new ArrayList<>();
        this.rCorrecta = rcorrecta;
        this.tematica = tematica;
        this.tipoContenido = tipoContenido;
        this.recurso = recurso;

        this.respuestas.add(rcorrecta);
        this.respuestas.add(rincorrecta1);
        this.respuestas.add(rincorrecta2);
        this.respuestas.add(rincorrecta3);

        this.ID = ID;
    }

    public String gettematica(){
        return tematica;
    }

    public String getTipoContenido(){
        return tipoContenido;
    }

    public ArrayList<String> getRespuestas(){
        return respuestas;
    }

    public String getTextoPregunta(){
        return pregunta;
    }

    public String getRespuestaCorrecta(){
        return rCorrecta;
    }

    public void setRespuestaElegida(String respuesta){
        respuestaElegida = respuesta;
    }

    public String getRespuestaElegida(){
        return respuestaElegida;
    }

    public String getRecurso(){
        return recurso;
    }
}
