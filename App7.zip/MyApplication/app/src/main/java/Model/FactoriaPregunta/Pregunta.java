package Model.FactoriaPregunta;

import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import Model.DatosPregunta;

/**
 * Created by Manuel on 06/05/2015.
 */
public abstract class Pregunta {
    protected static ArrayList<DatosPregunta> preguntasTematica;
    protected static ArrayList<DatosPregunta> preguntasTematicaImagen;
    protected static ArrayList<DatosPregunta> preguntasTematicaSonido;
    protected static ArrayList<DatosPregunta> preguntasTematicaTexto;

    public void shuffleRespuestas(DatosPregunta p) {
        Collections.shuffle(p.getRespuestas());
    }

    public static void setPreguntasTematicas(ArrayList<DatosPregunta> pT) {
        preguntasTematica = pT;
    }

    public DatosPregunta extraePregunta() {
        DatosPregunta aux;
        ArrayList<DatosPregunta> preguntasTematicaTipo;

        Random rnd = new Random();
        int tipoPregunta = (int)(rnd.nextDouble() * 3 + 1);

        switch(tipoPregunta){
            case 1:preguntasTematicaTipo = preguntasTematicaSonido;
                    break;
            case 2: preguntasTematicaTipo = preguntasTematicaImagen;
                    break;
            case 3: preguntasTematicaTipo = preguntasTematicaTexto;
                    break;
            default:
                preguntasTematicaTipo = preguntasTematicaTexto;
                break;
        }

        if (preguntasTematicaTipo.size()>0){
            Collections.shuffle(preguntasTematicaTipo);
            aux = preguntasTematicaTipo.get(0);
            shuffleRespuestas(aux);
            return aux;
        }else{
            aux = new DatosPregunta("","","","","","","","","");
            return aux;
        }
    }
}
