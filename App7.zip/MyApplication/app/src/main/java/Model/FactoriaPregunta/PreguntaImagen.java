package Model.FactoriaPregunta;

import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;

import Model.DatosPregunta;

/**
 * Created by Manuel on 06/05/2015.
 */
public class PreguntaImagen extends Pregunta {
    public PreguntaImagen(){
        preguntasTematicaImagen = new ArrayList<DatosPregunta>();
        for(DatosPregunta p: preguntasTematica){
            if(p.getTipoContenido().equals("Imagen")){
                preguntasTematicaImagen.add(p);
            }
        }

        //Reconoce de entre el arraylist de preguntas, aquellas
        //que tengan el formato de imagen y las mete en el arraylist de preguntasTematicaTipo.
        //SOLO CUANDO SE CREA EL OBJETO.
    }
}
