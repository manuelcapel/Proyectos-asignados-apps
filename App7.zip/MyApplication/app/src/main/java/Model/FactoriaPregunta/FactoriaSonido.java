package Model.FactoriaPregunta;

import android.util.Log;

/**
 * Created by Manuel on 06/05/2015.
 */
public class FactoriaSonido implements FactoriaPregunta{
    Pregunta psonido;

    @Override
    public Pregunta crearInstancia() {
        Pregunta psonido = new PreguntaSonido();
        return psonido;
    }
}
