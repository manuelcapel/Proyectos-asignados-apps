package Model.FactoriaPregunta;

/**
 * Created by Manuel on 06/05/2015.
 */
public interface FactoriaPregunta {
    public Pregunta crearInstancia();
}
