package Model.FactoriaPregunta;

/**
 * Created by Manuel on 06/05/2015.
 */
public class FactoriaImagen implements FactoriaPregunta {
    @Override
    public Pregunta crearInstancia() {
        Pregunta pimagen = new PreguntaImagen();
        return pimagen;
    }
}
