package Model.FactoriaPregunta;
import android.util.Log;

import java.util.Collections;
import java.util.ArrayList;

import Model.DatosPregunta;

/**
 * Created by Manuel on 06/05/2015.
 */
public class PreguntaSonido extends Pregunta {
    public PreguntaSonido(){

        preguntasTematicaSonido = new ArrayList<DatosPregunta>();
        for(DatosPregunta p: preguntasTematica){
            if(p.getTipoContenido().equals("Sonido")){
                preguntasTematicaSonido.add(p);
            }
        }
        //Reconoce de entre el arraylist de preguntas, aquellas
        //que tengan el formato de sonido y las mete en el arraylist de preguntasTematicaTipo.
        //SOLO CUANDO SE CREA EL OBJETO.
    }
}
