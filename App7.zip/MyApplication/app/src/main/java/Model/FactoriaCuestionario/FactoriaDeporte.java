package Model.FactoriaCuestionario;

/**
 * Created by Manuel on 06/05/2015.
 */
public class FactoriaDeporte implements FactoriaCuestionario {
    @Override
    public Cuestionario crearInstancia() {
        Cuestionario deportes = new Deportes();
        return deportes;
    }
}
