package Model.FactoriaCuestionario;

/**
 * Created by Manuel on 06/05/2015.
 */
public class FactoriaCine implements FactoriaCuestionario {
    @Override
    public Cuestionario crearInstancia() {
        Cuestionario cine = new Cine();
        return cine;
    }
}
