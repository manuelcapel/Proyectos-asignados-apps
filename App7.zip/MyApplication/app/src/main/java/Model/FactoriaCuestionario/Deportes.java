package Model.FactoriaCuestionario;

import android.util.Log;

import java.util.ArrayList;

import Model.DatosPregunta;
import Model.FactoriaPregunta.FactoriaImagen;
import Model.FactoriaPregunta.FactoriaPregunta;
import Model.FactoriaPregunta.FactoriaSonido;
import Model.FactoriaPregunta.FactoriaTexto;
import Model.FactoriaPregunta.Pregunta;

/**
 * Created by Manuel on 06/05/2015.
 */
public class Deportes extends Cuestionario {
    //extrae las preguntas de Deportes
    public Deportes(){
        ArrayList<DatosPregunta> filtradas = new ArrayList<>();
        for(DatosPregunta dp: preguntasTotales) {
            if (dp.gettematica().compareTo("Deportes")==0){
                filtradas.add(dp);
            }
        }

        Pregunta.setPreguntasTematicas(filtradas);
        FactoriaPregunta fp1;
        FactoriaPregunta fp2;
        FactoriaPregunta fp3;


        fp1 = new FactoriaImagen();
        pImagen = fp1.crearInstancia();
        fp2 = new FactoriaSonido();
        pSonido = fp2.crearInstancia();
        fp3 = new FactoriaTexto();
        pTexto = fp3.crearInstancia();
        //Ahora ya estamos listos para sacar pregunta a pregunta.
    }
}
