package Model.FactoriaCuestionario;

/**
 * Created by Manuel on 06/05/2015.
 */
public class FactoriaCienciaTecnologia implements FactoriaCuestionario {
    @Override
    public Cuestionario crearInstancia() {
        Cuestionario ciencia = new CienciaTecnologia();
        return ciencia;
    }
}
