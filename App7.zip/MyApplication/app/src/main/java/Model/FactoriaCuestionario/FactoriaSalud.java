package Model.FactoriaCuestionario;

/**
 * Created by Manuel on 06/05/2015.
 */
public class FactoriaSalud implements FactoriaCuestionario {
    @Override
    public Cuestionario crearInstancia() {
        Cuestionario vida = new Salud();
        return vida;
    }
}
