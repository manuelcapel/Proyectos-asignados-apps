package Model.FactoriaCuestionario;

/**
 * Created by Manuel on 06/05/2015.
 */
public interface FactoriaCuestionario {
    public Cuestionario crearInstancia();
}
