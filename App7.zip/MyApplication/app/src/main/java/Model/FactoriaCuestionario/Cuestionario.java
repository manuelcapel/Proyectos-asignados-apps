package Model.FactoriaCuestionario;

import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import Model.DatosPregunta;
import Model.FactoriaPregunta.Pregunta;
import Model.FactoriaPregunta.PreguntaImagen;
import Model.FactoriaPregunta.PreguntaTexto;
import preguntas.juego.mbrjfa.juegopreguntas.DBHelper;

/**
 * Created by Manuel on 06/05/2015.
 */
public abstract class Cuestionario {
    protected static ArrayList<DatosPregunta> preguntasTotales;
    protected Pregunta pImagen;
    protected Pregunta pSonido;
    protected Pregunta pTexto;

    public void rellenaCuestionario(){
        for(int i=0;i<10;i++){
        }
    }

    public Pregunta getPregunta() {
        int rangoTipoPregunta = 3;
        boolean parar = false;
        int tipoPregunta;
        Pregunta p = null;

        while (!parar) {
            tipoPregunta = (int) Math.random() * rangoTipoPregunta;
            switch (tipoPregunta) {
                case 0:
                    p = pTexto;
                    break;
                case 1:
                    p = pImagen;
                    break;
                case 2:
                    p = pSonido;
                    break;
                default: p = new PreguntaTexto();
                        break;
            }

            if(p.extraePregunta().getTextoPregunta()!=null){
                parar = true;
            }
        }

        if(p==null){
            p = new PreguntaTexto();
            return p;
        }else{
            return p;
        }
    }

    public static void setPreguntasTotales(ArrayList<DatosPregunta> pT){
        preguntasTotales = pT;
    }

}
