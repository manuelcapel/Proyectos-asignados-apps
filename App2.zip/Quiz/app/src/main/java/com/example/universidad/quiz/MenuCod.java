package com.example.universidad.quiz;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.io.IOException;
import java.sql.SQLException;

//Clase con las funciones del menu principal de la aplicacion
public class MenuCod extends ActionBarActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);

        Button accionJugar = (Button) findViewById(R.id.jug);
        accionJugar.setOnClickListener(this);

        Button accionSalir = (Button) findViewById(R.id.sal);
        accionSalir.setOnClickListener(this);

        Button accionPuntuacion = (Button) findViewById(R.id.pun);
        accionPuntuacion.setOnClickListener(this);

        Button otrosJu = (Button) findViewById(R.id.oju);
        otrosJu.setOnClickListener(this);

        // Esto es para inicializar la BD
        manejadorBD myDbHelper = new manejadorBD(this);

        try{
            myDbHelper.createDataBase();
        } catch(IOException ioe){
            throw new Error("Unable to create database");
        }

        myDbHelper.openDataBase();

    }

    public void onClick(View v){
        if (v.getId() == R.id.jug) {
            Intent i = new Intent(this, TemaCod.class);

            startActivity(i);
        }

        if (v.getId() == R.id.sal) {
            finish();
        }

        if (v.getId() == R.id.pun) {
            Intent i = new Intent(this, PuntuacionCod.class);

            startActivity(i);
        }

        if (v.getId() == R.id.oju) {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://play.google.com/store/apps/category/GAME_TRIVIA"));
            startActivity(i);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
