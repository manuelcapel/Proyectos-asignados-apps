package com.example.universidad.quiz;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

//Clase con las funciones de la pantalla de seleccion de menu
public class TemaCod extends ActionBarActivity implements View.OnClickListener{

    Button temTv;
    Button temDe;
    Button temGe;
    Button temAniI;
    Button temAniS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tema);

        temTv = (Button) findViewById(R.id.tem2);
        temTv.setOnClickListener(this);

        temDe = (Button) findViewById(R.id.tem3);
        temDe.setOnClickListener(this);

        temGe = (Button) findViewById(R.id.tem1);
        temGe.setOnClickListener(this);

        temAniI = (Button) findViewById(R.id.tem4);
        temAniI.setOnClickListener(this);

        temAniS = (Button) findViewById(R.id.tem5);
        temAniS.setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tema, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tem2) {
            Intent i = new Intent(this, JuegoCod.class);
            i.putExtra("tema", temTv.getText().toString());
            startActivity(i);
        }

        if (v.getId() == R.id.tem3) {
            Intent i = new Intent(this, JuegoCod.class);
            i.putExtra("tema", temDe.getText().toString());
            startActivity(i);
        }

        if (v.getId() == R.id.tem1) {
            Intent i = new Intent(this, JuegoCod.class);
            i.putExtra("tema", temGe.getText().toString());
            startActivity(i);
        }

        if (v.getId() == R.id.tem4) {
            Intent i = new Intent(this, JuegoCod.class);
            i.putExtra("tema", temAniI.getText().toString());
            startActivity(i);
        }

        if (v.getId() == R.id.tem5) {
            Intent i = new Intent(this, JuegoCod.class);
            i.putExtra("tema", temAniS.getText().toString());
            startActivity(i);
        }
    }
}
