package com.example.universidad.quiz;

//Clase que hereda de la clase pregunta y que se una para las preguntas con sonido
public class preguntaSon extends pregunta {

    private String sound;

    public preguntaSon(String pre, String tipo, int idPre, String formato, int idRes, String tipRes, String sou) {
        super(pre, tipo, idPre, formato, idRes, tipRes);
        sound = sou;
    }

    public String getSound(){
        return sound;
    }
}
