package com.example.universidad.quiz;

//Clase que hereda de la clase pregunta y que se una para las preguntas con solo texto
public class preguntaTex extends pregunta {


    public preguntaTex(String pre, String tipo, int idPre, String formato, int idRes, String tipRes) {
        super(pre, tipo, idPre, formato, idRes, tipRes);
    }
}
