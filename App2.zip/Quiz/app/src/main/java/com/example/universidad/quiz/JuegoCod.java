package com.example.universidad.quiz;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

//Clase con las funciones del juego
public class JuegoCod extends ActionBarActivity implements View.OnClickListener{

    //Este handler sirve para espera 2 seg antes de pasa a la siguiente pregunta despues de responder o pasa la pantalla final
    //cuando se hayan respondido todas las preguntas
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                if(cont==numPre) {
                    sigAc();
                }
                else
                    updPre(lispre[cont], tema);
            }
        }
    };

    //Variables para reproduccion de sonido
    private MediaPlayer mp;
    private MediaPlayer mp2;

    //Numero de preguntas del juego
    private int numPre = 5;

    //Pregunta actual del juego
    private pregunta preg = null;

    //Lista de Keys de las preguntas del juego actual
    private int[] lispre = new int[numPre];

    //Iterador que recorre la lista de Keys de preguntas
    private int cont = 0;

    //Tema de las preguntas del juego
    String tema = new String();

    //Formato de las preguntas del juego
    String formato = new String();

    //Elementos de la pantalla
    private TextView pre;
    private Button res1;
    private Button res2;
    private Button res3;
    private Button res4;
    private ImageView ima;
    private ImageButton contb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.juego);

        mp = new MediaPlayer();
        mp2 = new MediaPlayer();

        //Se guardan los elementos del layaut
        pre = (TextView) findViewById(R.id.pre);
        res1 = (Button) findViewById(R.id.res1);
        res2 = (Button) findViewById(R.id.res2);
        res3 = (Button) findViewById(R.id.res3);
        res4 = (Button) findViewById(R.id.res4);
        ima = (ImageView) findViewById(R.id.ima);
        contb = (ImageButton) findViewById(R.id.cont);

        //Se le asigna un evento de click
        res1.setOnClickListener(this);
        res2.setOnClickListener(this);
        res3.setOnClickListener(this);
        res4.setOnClickListener(this);
        ima.setOnClickListener(this);

        //Cogemos el tema indicado en el activity anterior
        tema = getIntent().getExtras().getString("tema");

        //Obtenemos de la base de datos una lista de Keys al azar de preguntas
        manejadorBD db1 = new manejadorBD(this);
        SQLiteDatabase db = db1.getWritableDatabase();

        String[] param  = new String[2];
        param[0] = tema;
        param[1] = String.valueOf(numPre);

        Cursor micursor = db.rawQuery("SELECT _idPre,formato from preguntas where tipo=? ORDER BY RANDOM() LIMIT ?", param);

        for (int i = 0; micursor.moveToNext(); i++) {
            lispre[i] = Integer.parseInt(micursor.getString(0));
            formato = micursor.getString(1);
        }

        //Reiniciamos la puntuacion para el nuevo juego
        db.execSQL("UPDATE puntuacion SET puntuacion=0");

        db.close();

        //Actualizamos la pregunta actual
        updPre(lispre[cont], tema);
    }

    public void onClick(View v){

        Button aux;

        if((v.getId() == R.id.res1 || v.getId() == R.id.res2 || v.getId() == R.id.res3
                || v.getId() == R.id.res4) && contb.getVisibility()==View.INVISIBLE){
            aux = (Button) findViewById(v.getId());

            //Comprobamos si la pregunta seleccionada es la correcta
            manejadorBD db1 = new manejadorBD(this);
            SQLiteDatabase db = db1.getWritableDatabase();

            String[] param = new String[1];
            param[0] = String.valueOf(preg.getIdRes());

            Cursor micursor = db.rawQuery("SELECT * from " + preg.getTipoRes() + " where _idRes=?", param);
            micursor.moveToFirst();

            //Si es correcta el boton se pone en verde si no en rojo y espera 2 seg para cargar la siguiente pregunta
            if (micursor.getString(0).equals(aux.getText())) {
                aux.setBackgroundColor(Color.GREEN);
                contb.setBackgroundResource(R.drawable.correcto);
                contb.setVisibility(View.VISIBLE);
                mp= MediaPlayer.create(this, R.raw.correctsound);
                mp.start();
                db.execSQL("UPDATE puntuacion SET puntuacion=puntuacion+20");
                handler.sendEmptyMessageDelayed(1, 2000);
            } else {
                aux.setBackgroundColor(Color.RED);
                contb.setBackgroundResource(R.drawable.incorrecto);
                contb.setVisibility(View.VISIBLE);
                mp= MediaPlayer.create(this, R.raw.failsound);
                mp.start();
                handler.sendEmptyMessageDelayed(1, 2000);
            }
            db.close();
        }

        //Evento para poder volver a reproducir el sonido
        else if(v.getId() == R.id.ima){
            mp2.start();
        }
    }

    //Funcion que actualiza la pregunta actual
    public void updPre(int num, String tipo){
        cont++;

        manejadorBD db1 = new manejadorBD(this);
        SQLiteDatabase db = db1.getWritableDatabase();

        String[] param  = new String[2];
        param[0] = String.valueOf(num);
        param[1] = tipo;

        //Dependiendo del tipo de pregunta(sonido, imagen o solo texto) inicializa el objeto preg a uno y otro y le pasa los datos
        Cursor micursor = db.rawQuery("SELECT * from preguntas where _idPre=? AND tipo=?", param);
        micursor.moveToFirst();
        if(formato.equals("TEXTO"))
            preg = new preguntaTex(micursor.getString(0), micursor.getString(1), Integer.parseInt(micursor.getString(2)),
                    micursor.getString(3),Integer.parseInt(micursor.getString(4)),micursor.getString(5));
        else if(formato.equals("IMAGEN"))
            preg = new preguntaIma(micursor.getString(0), micursor.getString(1), Integer.parseInt(micursor.getString(2)),
                    micursor.getString(3),Integer.parseInt(micursor.getString(4)),micursor.getString(5), micursor.getString(7));
        else if(formato.equals("SONIDO"))
            preg = new preguntaSon(micursor.getString(0), micursor.getString(1), Integer.parseInt(micursor.getString(2)),
                    micursor.getString(3),Integer.parseInt(micursor.getString(4)),micursor.getString(5), micursor.getString(6));

        //Obtiene una lista de respuesta entre las cuales esta la correcta
        boolean estRes = false;
        String[] aux = new String[4];
        while(!estRes) {
            micursor = db.rawQuery("SELECT * FROM " + preg.getTipoRes() + " ORDER BY RANDOM() LIMIT 4", null);

            for (int i = 0; micursor.moveToNext(); i++) {
                if (Integer.parseInt(micursor.getString(1)) == preg.getIdRes()) {
                    estRes = true;
                    aux[i] = micursor.getString(0);
                } else
                    aux[i] = micursor.getString(0);
            }
        }

        preg.setRes(aux);

        db.close();

        int resID;
        int resID2;

        //Si la pregunta es de tipo imagen carga la imagen en la pantalla
        if(preg instanceof preguntaIma) {
            resID = getResources().getIdentifier(((preguntaIma) preg).getImagen(), "drawable", getPackageName());
            ima.setBackgroundResource(resID);
        }

        //Si la pregunta es de tipo sonido carga el sonido en la pantalla
        if(preg instanceof preguntaSon) {
            resID = getResources().getIdentifier(((preguntaSon) preg).getSound(), "raw", getPackageName());
            resID2 = getResources().getIdentifier("soundicon", "drawable", getPackageName());
            ima.setBackgroundResource(resID2);
            mp2 = MediaPlayer.create(this, resID);
            mp2.start();
        }

        //Actualiza los botones con las nuevas repuestas posibles
        pre.setText(preg.getPre());
        res1.setText(preg.getRes(0));
        res2.setText(preg.getRes(1));
        res3.setText(preg.getRes(2));
        res4.setText(preg.getRes(3));

        res1.setBackgroundColor(Color.parseColor("#ffffee65"));
        res2.setBackgroundColor(Color.parseColor("#ffffee65"));
        res3.setBackgroundColor(Color.parseColor("#ffffee65"));
        res4.setBackgroundColor(Color.parseColor("#ffffee65"));

        contb.setVisibility(View.INVISIBLE);
    }

    //Pasa a la pantalla final
    public void sigAc(){
        Intent i = new Intent(this, felicitacionesCod.class);
        startActivity(i);
    }

}