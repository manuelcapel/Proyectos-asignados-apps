package com.example.universidad.quiz;


//Clase abstrasta la cual almacena los datos de cada pregunta
public class pregunta{

    private String pre;
    private String tipo;
    private int idPre;
    private String formato;
    private int idRes;
    private String tipoRes;
    private String[] res;

    public pregunta(String pre, String tipo, int idPre, String formato, int idRes, String tipRes){
        this.pre = pre;
        this.tipo = tipo;
        this.idPre = idPre;
        this.formato = formato;
        this.idRes = idRes;
        this.tipoRes = tipRes;
    }

    public void setRes(String[] resp){
        res = new String[4];
        res = resp;
    }

    public String getPre(){
        return pre;
    }

    public String getTipo(){
        return tipo;
    }

    public int getIdPre(){
        return idPre;
    }

    public String getFormato(){
        return formato;
    }

    public int getIdRes(){
        return idRes;
    }

    public String getTipoRes(){
        return tipoRes;
    }

    public String getRes(int i){ return res[i]; }
}
