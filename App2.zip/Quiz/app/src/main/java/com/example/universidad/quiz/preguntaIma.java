package com.example.universidad.quiz;

//Clase que hereda de la clase pregunta y que se una para las preguntas con imagen
public class preguntaIma extends pregunta {

    private String imagen;

    public preguntaIma(String pre, String tipo, int idPre, String formato, int idRes, String tipRes, String ima) {
        super(pre, tipo, idPre, formato, idRes, tipRes);
        imagen = ima;
    }

    public String getImagen(){
        return imagen;
    }

}
