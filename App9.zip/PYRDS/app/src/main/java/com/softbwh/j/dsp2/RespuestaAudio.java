package com.softbwh.j.dsp2;

public class RespuestaAudio extends Respuesta {

    public RespuestaAudio(String r, String ra, String id_r) {
        super(r, ra, id_r);
    }
}
