package com.softbwh.j.dsp2;
import java.util.ArrayList;


public class EnunciadoAudio extends Enunciado {

    public EnunciadoAudio(Pregunta p, ArrayList<Respuesta> r) {
        super(p, r);
    }

}
