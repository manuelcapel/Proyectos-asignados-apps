package com.softbwh.j.dsp2;

public class RespuestaTexto extends Respuesta {


    public RespuestaTexto(String r, String id_r) {
        super(r,"0", id_r);
    }

}
