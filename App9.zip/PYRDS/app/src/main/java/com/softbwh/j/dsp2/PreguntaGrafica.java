package com.softbwh.j.dsp2;

public class PreguntaGrafica extends Pregunta {

    public PreguntaGrafica(String cont, Respuesta r, String rg, String tip) {
        super(cont, r, rg, tip);
    }
}
