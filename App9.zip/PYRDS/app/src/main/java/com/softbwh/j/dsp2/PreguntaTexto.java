package com.softbwh.j.dsp2;

public class PreguntaTexto extends Pregunta {

    
    public PreguntaTexto(String cont, Respuesta r, int rt, String tip) {
        super(cont, r, "0", tip);
    }

}
