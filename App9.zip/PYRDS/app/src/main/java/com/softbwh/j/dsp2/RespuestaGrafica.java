package com.softbwh.j.dsp2;

public class RespuestaGrafica extends Respuesta {

    public RespuestaGrafica(String r, String ri, String id_r) {
        super(r, ri, id_r);
    }
}
