package com.softbwh.j.dsp2;
import java.util.ArrayList;


public class EnunciadoTexto extends Enunciado {

    public EnunciadoTexto(Pregunta p, ArrayList<Respuesta> r) {
        super(p, r);
    }

}
