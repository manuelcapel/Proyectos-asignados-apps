package com.softbwh.j.dsp2;

public class PreguntaAudio extends Pregunta {

    public PreguntaAudio(String cont, Respuesta r, String ra, String tip) {
        super(cont, r, ra, tip);
    }

}
