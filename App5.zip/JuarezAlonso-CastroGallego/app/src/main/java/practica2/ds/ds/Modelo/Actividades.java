package practica2.ds.ds.Modelo;

/**
 * Created by garcas on 28/04/2015.
 */
public interface Actividades {


    public int getTipo();
    public void setTipo(int tipo);
}
