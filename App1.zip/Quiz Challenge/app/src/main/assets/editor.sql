--CREATE TABLE Answer 
--(
--	id			INTEGER   PRIMARY KEY, 
--	ans1		text, 
--	ans2		text, 
--	ans3		text, 
--	ans4		text, 
--	correct		INTEGER CHECK( correct<5 & correct>0 )
--);


--drop table Quiz;
--CREATE TABLE Quiz 
--(
--	id			INTEGER   PRIMARY KEY, 
--	quiz		text,
--	idAnswer 	references Answer(id),
--	idTopic 	REFERENCES Topic(id)
--);


--CREATE TABLE Topic 
--(
--	id			INTEGER   PRIMARY KEY, 
--	topic		text
--);


--insert into Topic(topic) values ("Ciencias");
--INSERT INTO Topic(topic) VALUES ("Deportes");
--INSERT INTO Topic(topic) VALUES ("Música");
--INSERT INTO Topic(topic) VALUES ("Geografía e Historia");
--INSERT INTO Topic(topic) VALUES ("Arte");
--INSERT INTO Topic(topic) VALUES ("Ocio");

--INSERT INTO Answer VALUES (0, "Tom Geiguen", "Carlo", "Fredo", "Tessio", 4);
--INSERT INTO Quiz (quiz, idAnswer, idTopic) VALUES ("Tras la muerte de Vito en la película El Padrino, ¿quien intenta traicionar a Michel?", 0, 6);

--INSERT INTO Answer VALUES (2, "Hermione Granger", "Emma Watson", "Sasha Grey", "Katie Holmes", 2);
--INSERT INTO Quiz (quiz, idAnswer, idTopic) VALUES ("¿Cómo se llama la actriz que protagoniza a Hermione Granger?", 2, 6);

--INSERT INTO Answer VALUES (1, "2005", "2004", "2006", "2007", 3);
--INSERT INTO Quiz (quiz, idAnswer, idTopic) VALUES ("¿En qué año se editó 'Stadium Arcadium' de Red Hot Chilli Peppers?", 1, 3);

--select * from Quiz;
--SELECT * FROM Answer;


SELECT * FROM Quiz WHERE idTopic=6 ORDER BY random() LIMIT 1;


--SELECT * FROMM Topic;