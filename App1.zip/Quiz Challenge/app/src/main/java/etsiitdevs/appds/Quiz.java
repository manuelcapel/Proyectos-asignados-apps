package etsiitdevs.appds;

import android.text.style.QuoteSpan;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by juanpi on 25/04/15.
 */
public abstract class Quiz
{

    private Question question;
    private Answers answers;
    private Topic topic;

    public abstract Question getQuestion();

    public abstract Answers getAnswers();

    public abstract Topic getTopic();

    public abstract int getCorrect();
}
