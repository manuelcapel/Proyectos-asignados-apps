package etsiitdevs.appds;

/**
 * Created by juanpi on 11/05/15.
 */
public enum Topic
{
    Ciencias,
    Deportes,
    GeografiaHistoria,
    Arte,
    Ocio,
    Musica;


    public static int getTopic(Topic t)
    {
        int id = -1;
        switch (t)
        {
            case Ciencias: id = 1;
                break;
            case Deportes: id = 2;
                break;
            case GeografiaHistoria: id = 3;
                break;
            case Arte: id = 4;
                break;
            case Ocio: id = 5;
                break;
            case Musica: id = 6;
                break;
        }

        return id;
    }


    public static Topic getTopic(int id)
    {
        Topic t = null;
        switch (id)
        {
            case 1: t = Ciencias;
                break;
            case 2: t = Deportes;
                break;
            case 3: t = GeografiaHistoria;
                break;
            case 4: t = Arte;
                break;
            case 5: t = Ocio;
                break;
            case 6: t = Musica;
                break;
        }

        return t;
    }


    public static String toString(Topic t)
    {
        String s = "";
        switch (t)
        {
            case Ciencias: s = "Ciencias";
                break;
            case Deportes: s = "Deportes";
                break;
            case GeografiaHistoria: s = "Geografía e Historia";
                break;
            case Arte: s = "Arte";
                break;
            case Ocio: s = "Ocio";
                break;
            case Musica: s = "Música";
                break;
        }

        return s;
    }

}
