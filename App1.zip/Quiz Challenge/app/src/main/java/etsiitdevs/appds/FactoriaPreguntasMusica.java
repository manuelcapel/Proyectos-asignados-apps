package etsiitdevs.appds;

import android.content.Context;

import java.sql.SQLException;

/**
 * Created by juanpi on 11/05/15.
 */
public class FactoriaPreguntasMusica extends FactoriaPreguntas {

    private DBHelper db;

    private static final Topic t = Topic.Musica;

    public FactoriaPreguntasMusica()
    {
        db = DBHelper.getInstance();
    }

    @Override
    public QuizMusica getQuestion() {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        QuizMusica q = (QuizMusica) db.getQuiz(Topic.getTopic(t));
        db.close();
        return q;
    }
}