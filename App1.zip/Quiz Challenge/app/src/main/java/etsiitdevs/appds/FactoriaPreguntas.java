package etsiitdevs.appds;

/**
 * Created by juanpi on 11/05/15.
 */
public abstract class FactoriaPreguntas
{

    private DBHelper db;

    public abstract Quiz getQuestion();
}
