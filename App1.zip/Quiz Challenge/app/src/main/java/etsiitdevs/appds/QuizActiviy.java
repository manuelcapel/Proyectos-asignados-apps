package etsiitdevs.appds;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import java.sql.SQLException;
import java.util.ArrayList;


public class QuizActiviy extends ActionBarActivity
{

    private TextView quiz;
    private TextView[] answers;
    private TextView topic;

    private TextView contador;
    private TextView tiempo;
    private CuentaAtras cuentaAtras;
    private MediaPlayer win, lose;

    Control c;

    // Animation
    private Animation contadorAnim;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        quiz = (TextView) findViewById(R.id.quiz);
        answers = new TextView[]{(TextView) findViewById(R.id.answer1),
                (TextView) findViewById(R.id.answer2), (TextView) findViewById(R.id.answer3),
                (TextView) findViewById(R.id.answer4)};
        topic = (TextView) findViewById(R.id.topic);

        contador = (TextView) findViewById(R.id.contador);
        tiempo = (TextView) findViewById(R.id.tiempo);

        win = MediaPlayer.create(this,R.raw.win);
        lose = MediaPlayer.create(this,R.raw.lose);

        // load the animation
        contadorAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.contador);


        c = new Control(this.getApplicationContext());

        rellenarQuiz();

        answers[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comprobarRespuesta(1);
            }
        });

        answers[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comprobarRespuesta(2);
            }
        });

        answers[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comprobarRespuesta(3);
            }
        });

        answers[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comprobarRespuesta(4);
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }

    @Override
    public void onPause() {
        super.onPause();
        cuentaAtras.cancel();
    }




    public void rellenarQuiz()
    {
        for(TextView a : answers)
            a.setBackgroundResource(R.drawable.button);

        Quiz q = c.getNextQuiz();
        if(q == null)
        {
            Intent i = new Intent(this, StatsActivity.class);
            startActivity(i);
            finish();
        }
        else {
            topic.setText(q.getTopic().toString());

            switch (q.getTopic()) {
                case Ciencias:
                    topic.setBackgroundResource(R.drawable.ciencias);
                    break;
                case Deportes:
                    topic.setBackgroundResource(R.drawable.deportes);
                    break;
                case GeografiaHistoria:
                    topic.setBackgroundResource(R.drawable.geohis);
                    break;
                case Arte:
                    topic.setBackgroundResource(R.drawable.arte);
                    break;
                case Ocio:
                    topic.setBackgroundResource(R.drawable.ocio);
                    break;
                case Musica:
                    topic.setBackgroundResource(R.drawable.musica);
                    break;
            }
            quiz.setText(q.getQuestion().getQuestion());
            ArrayList<String> ans = q.getAnswers().getAnswers();

            answers[0].setText(ans.get(0));
            answers[1].setText(ans.get(1));
            answers[2].setText(ans.get(2));
            answers[3].setText(ans.get(3));
            activar();
            cuentaAtras = null;
            cuentaAtras = new CuentaAtras(19 * 1000, 1000);
            cuentaAtras.start();
            contador.startAnimation(contadorAnim);
        }
    }

    public void desactivar()
    {
        for(TextView a : answers)
            a.setClickable(false);
    }

    public void activar()
    {
        for(TextView a : answers)
            a.setClickable(true);
    }


    public void comprobarRespuesta(int r)
    {
        desactivar();
        cuentaAtras.cancel();
        if(r>0)
            answers[r - 1].setBackgroundResource(R.drawable.button_incorrect);
        else
            tiempo.setText("0'");

        if (c.getCurrentQuiz().getCorrect()==r)
            win.start();
        else
            lose.start();

        c.comprobarRespuesta(r);

        contadorAnim.cancel();
        answers[c.getCurrentQuiz().getCorrect()-1].setBackgroundResource(R.drawable.button_correct);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
            // acciones que se ejecutan tras los milisegundos
            rellenarQuiz();
            }
        }, 1000);
    }


    //Nuestra clase CountDownTimer modificada
    public class CuentaAtras extends CountDownTimer
    {
        private long tmp;
        private long inter;

        public CuentaAtras(long starTime, long interval) {
            super(starTime, interval);
            tmp = starTime/1000;
            inter = interval/1000;
        }

        @Override
        public void onFinish() {
            comprobarRespuesta(-1);
        }

        @Override
        public void onTick(long millisUntilFinished)
        {
            tmp -= inter;
            tiempo.setText(String.valueOf(tmp)+"'");
        }

    }
}
