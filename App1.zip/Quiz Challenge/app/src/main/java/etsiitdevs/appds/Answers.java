package etsiitdevs.appds;

import java.util.ArrayList;

/**
 * Created by juanpi on 11/05/15.
 */
public class Answers
{
    private ArrayList<String> answers;

    private int correct;

    public Answers(String a1, String a2, String a3, String a4, int c)
    {
        answers = new ArrayList<String>();

        answers.add(a1);
        answers.add(a2);
        answers.add(a3);
        answers.add(a4);

        correct = c;
    }


    public String getAnswer(int id)
    {
        return answers.get(id);
    }

    public ArrayList<String> getAnswers()
    {
        return answers;
    }


    public int getCorrect()
    {
        return correct;
    }

}
