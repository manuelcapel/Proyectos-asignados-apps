package etsiitdevs.appds;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;

/**
 * Created by juanpi on 20/04/15.
 */


public class DBHelper extends SQLiteOpenHelper
{

    private static DBHelper instance = null;

    //Ruta por defecto de las bases de datos en el sistema Android
    private static String DB_PATH = "/data/data/etsiitdevs.appds/databases/";

    private static String DB_NAME = "DBDS.db";

    private SQLiteDatabase myDataBase;

    private final Context myContext;

    private int nTopics;
    private int nQuestions;


    public static DBHelper getInstance(Context context)
    {
        if (instance == null)
            instance = new DBHelper(context);

        return instance;
    }


    public static DBHelper getInstance()
    {
        return instance;
    }

    /**
     * Constructor
     * Toma referencia hacia el contexto de la aplicación que lo invoca para poder acceder a los
     * 'assets' y 'resources' de la aplicación.
     * Crea un objeto DBOpenHelper que nos permitirá controlar la apertura de la base de datos.
     *
     * @param context
     */
    private DBHelper(Context context) {

        super(context, DB_NAME, null, 1);
        this.myContext = context;

    }

    /**
     * Crea una base de datos vacía en el sistema y la reescribe con nuestro fichero de base de datos.
     */
    public boolean createDataBase() throws IOException {

        boolean dbExist = checkDataBase();

        if (dbExist) {
            //la base de datos existe y no hacemos nada.
        } else {
            //Llamando a este método se crea la base de datos vacía en la ruta por defecto del sistema
            //de nuestra aplicación por lo que podremos sobreescribirla con nuestra base de datos.
            this.getReadableDatabase();

            try {

                copyDataBase();

            } catch (IOException e) {
                throw new Error("Error copiando Base de Datos");
            }
        }
        return dbExist;
    }

    /**
     * Comprueba si la base de datos existe para evitar copiar siempre el fichero cada vez que se abra la aplicación.
     *
     * @return true si existe, false si no existe
     */
    private boolean checkDataBase() {

        SQLiteDatabase checkDB = null;

        try {

            String myPath = DB_PATH + DB_NAME;
            checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);

        } catch (SQLiteException e) {

            //si llegamos aqui es porque la base de datos no existe todavía.

        }
        if (checkDB != null) {

            checkDB.close();

        }
        return checkDB != null ? true : false;
    }

    /**
     * Copia nuestra base de datos desde la carpeta assets a la recién creada
     * base de datos en la carpeta de sistema, desde dónde podremos acceder a ella.
     * Esto se hace con bytestream.
     */
    private void copyDataBase() throws IOException {

        //Abrimos el fichero de base de datos como entrada
        InputStream myInput = myContext.getAssets().open(DB_NAME);

        //Ruta a la base de datos vacía recién creada
        String outFileName = DB_PATH + DB_NAME;

        //Abrimos la base de datos vacía como salida
        OutputStream myOutput = new FileOutputStream(outFileName);

        //Transferimos los bytes desde el fichero de entrada al de salida
        byte[] buffer = new byte[1024];
        int length;
        while ((length = myInput.read(buffer)) > 0) {
            myOutput.write(buffer, 0, length);
        }

        //Liberamos los streams
        myOutput.flush();
        myOutput.close();
        myInput.close();

    }


    //Sentencia SQL para crear la tabla de Stats
    String sqlCreate = "CREATE TABLE IF NOT EXISTS Stats (topic integer primary key references Topic(id), totales integer," +
            " acertadas integer);";

    public void open() throws SQLException
    {
        boolean dbExist;

        //Abre la base de datos
        try {
            dbExist = createDataBase();
        } catch (IOException e) {
            throw new Error("Ha sido imposible crear la Base de Datos");
        }

        String myPath = DB_PATH + DB_NAME;
        myDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READWRITE);

        Cursor c = myDataBase.rawQuery("SELECT count(*) FROM Topic;", null);
        c.moveToFirst();

        nTopics = Integer.parseInt(c.getString(0));

        c = myDataBase.rawQuery("SELECT count(*) FROM Quiz;", null);
        c.moveToFirst();

        nQuestions = Integer.parseInt(c.getString(0));

        if(!dbExist) {
            //Se ejecuta la sentencia SQL de creación de la tabla
            myDataBase.execSQL(sqlCreate);
            for (int i = 1; i <= nTopics; i++)
                myDataBase.execSQL("INSERT INTO Stats (topic, totales, acertadas) VALUES (" + i + ", 0, 0);");
        }
    }

    @Override
    public synchronized void close() {
        if (myDataBase != null)
            myDataBase.close();
        super.close();
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    public int getnTopics()
    {
        return nTopics;
    }

    public int getnQuestions()
    {
        return nQuestions;
    }

    public void updateStats(int[] acertadas, int n)
    {
        for(int i=1; i<=nTopics; i++)
        {
            String select = "select acertadas from Stats where topic="+i+";";
            Cursor c = myDataBase.rawQuery(select, null);
            c.moveToFirst();
            int last = Integer.parseInt(c.getString(0));
            int now = last+acertadas[i-1];
            myDataBase.execSQL("UPDATE Stats SET acertadas="+now+" where topic="+i+";");

            select = "select totales from Stats where topic="+i+";";
            c = myDataBase.rawQuery(select, null);
            c.moveToFirst();
            last = Integer.parseInt(c.getString(0));
            now = last+n;
            myDataBase.execSQL("UPDATE Stats SET totales="+now+" where topic="+i+";");
        }
    }


    public void reiniciarStats()
    {
        for (int i = 1; i <= nTopics; i++) {
            myDataBase.execSQL("UPDATE Stats SET acertadas=" + 0 + " where topic=" + i + ";");
            myDataBase.execSQL("UPDATE Stats SET totales=" + 0 + " where topic=" + i + ";");
        }
    }

    public int[] getStats(int n)
    {
        String select = "select acertadas,totales from Stats where topic="+n+";";
        Cursor c = myDataBase.rawQuery(select, null);
        c.moveToFirst();
        int acertadas = Integer.parseInt(c.getString(0));
        int totales = Integer.parseInt(c.getString(1));

        return new int[] {acertadas, totales};
    }


    public Quiz getQuiz(int topic)
    {
        Quiz q = null;

        String select = "select * from Quiz where idTopic="+topic+" order by random() limit 1;";
        Cursor c = myDataBase.rawQuery(select, null);
        c.moveToFirst();

        String ques = c.getString(1);
        String idAnswer = c.getString(2);
        String idTopic = c.getString(3);

        c.close();
        select = "select ans1,ans2,ans3,ans4,correct from Answer where id="+idAnswer+";";
        c = myDataBase.rawQuery(select, null);
        c.moveToFirst();

        String a1 = c.getString(0);
        String a2 = c.getString(1);
        String a3 = c.getString(2);
        String a4 = c.getString(3);
        int correct = Integer.parseInt(c.getString(4));

        switch (Topic.getTopic(topic))
        {
            case Ciencias: q = new QuizCiencias(ques, a1, a2, a3, a4, correct, Topic.getTopic(topic));
                break;
            case Deportes:q = new QuizDeportes(ques, a1, a2, a3, a4, correct, Topic.getTopic(topic));
                break;
            case GeografiaHistoria: q = new QuizGeoHis(ques, a1, a2, a3, a4, correct, Topic.getTopic(topic));
                break;
            case Arte: q = new QuizArte(ques, a1, a2, a3, a4, correct, Topic.getTopic(topic));
                break;
            case Ocio: q = new QuizOcio(ques, a1, a2, a3, a4, correct, Topic.getTopic(topic));
                break;
            case Musica: q = new QuizMusica(ques, a1, a2, a3, a4, correct, Topic.getTopic(topic));
                break;
        }

        c.close();
        return q;
    }



}

