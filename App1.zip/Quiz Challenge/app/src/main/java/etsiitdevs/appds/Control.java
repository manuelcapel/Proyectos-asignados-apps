package etsiitdevs.appds;

import android.content.Context;

/**
 * Created by juanpi on 13/05/15.
 */
public class Control {


    private Quiz q;
    private DBHelper db;
    private int id = 1;
    private int round = 0;

    private int[] acertadas;
    private FactoriaPreguntas factoria;

    StatsDB sDB;


    public Control(Context c)
    {
        db = DBHelper.getInstance(c);

        sDB = new StatsDB(c);

        acertadas = new int[6];
        for(int i=0; i<6; i++) acertadas[i] = 0;
    }

    public Quiz getCurrentQuiz()
    {
        return q;
    }


    private void updateStats(int[] acertadas)
    {
        sDB.updateStats(acertadas, round);
    }


    public Quiz getNextQuiz()
    {
        if(id > db.getnTopics())
        {
            id = 1;
            round++;
            if(round >= 2) {
                q = null;
                updateStats(acertadas);
            }
        }
        if (round < 2) {
            switch (Topic.getTopic(id)) {
                case Ciencias:
                    factoria = new FactoriaPreguntasCiencias();
                    q = factoria.getQuestion();
                    break;
                case Deportes:
                    factoria = new FactoriaPreguntasDeportes();
                    q = factoria.getQuestion();
                    break;
                case GeografiaHistoria:
                    factoria = new FactoriaPreguntasGeoHis();
                    q = factoria.getQuestion();
                    break;
                case Arte:
                    factoria = new FactoriaPreguntasArte();
                    q = factoria.getQuestion();
                    break;
                case Ocio:
                    factoria = new FactoriaPreguntasOcio();
                    q = factoria.getQuestion();
                    break;
                case Musica:
                    factoria = new FactoriaPreguntasMusica();
                    q = factoria.getQuestion();
                    break;
            }

            id++;
        }

        return q;
    }


    public void comprobarRespuesta(int r)
    {
        if(r == q.getCorrect())
            acertadas[id-2] += 1;
    }
}
