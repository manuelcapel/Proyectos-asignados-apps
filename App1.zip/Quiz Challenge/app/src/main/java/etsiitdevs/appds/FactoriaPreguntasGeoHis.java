package etsiitdevs.appds;

import android.content.Context;

import java.sql.SQLException;

/**
 * Created by juanpi on 11/05/15.
 */
public class FactoriaPreguntasGeoHis extends FactoriaPreguntas {

    private DBHelper db;

    private static final Topic t = Topic.GeografiaHistoria;

    public FactoriaPreguntasGeoHis()
    {
        db = DBHelper.getInstance();
    }

    @Override
    public QuizGeoHis getQuestion() {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        QuizGeoHis q = (QuizGeoHis) db.getQuiz(Topic.getTopic(t));
        db.close();
        return q;
    }
}