package etsiitdevs.appds;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.CountDownTimer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class StatsActivity extends ActionBarActivity {

    ArrayList<TextView> topics = new ArrayList<>();
    ArrayList<TextView> stopics = new ArrayList<>();

    ImageView reiniciarIMG;
    TextView reiniciarTXT;

    private Animation rotate;

    StatsDB sDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        topics.add((TextView) this.findViewById(R.id.statsTopic1));
        topics.add((TextView) this.findViewById(R.id.statsTopic2));
        topics.add((TextView) this.findViewById(R.id.statsTopic3));
        topics.add((TextView) this.findViewById(R.id.statsTopic4));
        topics.add((TextView) this.findViewById(R.id.statsTopic5));
        topics.add((TextView) this.findViewById(R.id.statsTopic6));

        stopics.add((TextView) this.findViewById(R.id.sTopic1));
        stopics.add((TextView) this.findViewById(R.id.sTopic2));
        stopics.add((TextView) this.findViewById(R.id.sTopic3));
        stopics.add((TextView) this.findViewById(R.id.sTopic4));
        stopics.add((TextView) this.findViewById(R.id.sTopic5));
        stopics.add((TextView) this.findViewById(R.id.sTopic6));


        reiniciarIMG = (ImageView) this.findViewById(R.id.reiniciarIMG);
        reiniciarTXT = (TextView) this.findViewById(R.id.reiniciarTXT);


        sDB = new StatsDB(this.getApplicationContext());

        actualizar();


        // load the animation
        rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);

        reiniciarIMG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarIMG.startAnimation(rotate);
                sDB.reiniciarStats();
                actualizar();
            }
        });

        reiniciarTXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarIMG.startAnimation(rotate);
                sDB.reiniciarStats();
                actualizar();
            }
        });

    }

    public StatsDB getStatsDB() {
        return sDB;
    }


    //Nuestra clase CountDownTimer modificada
    public class CuentaAtras extends CountDownTimer
    {
        private long tmp;
        private long inter;
        private TextView tv;
        private float p;

        private static final float inicio = 1.0f;
        private float s = inicio;
        private float intervalo;

        public CuentaAtras(long starTime, long interval, TextView tv, float p) {
            super(starTime, interval);
            tmp = starTime/1000;
            inter = interval/1000;
            this.tv = tv;
            this.p = p;
            this.intervalo = (this.p-this.inicio)/(starTime/(interval*1.0f));
        }

        @Override
        public void onFinish() {
            tv.setText(String.format("%.0f", p)+"%");
        }

        @Override
        public void onTick(long millisUntilFinished)
        {
            s += this.intervalo;
            tv.setText(String.format("%.0f", s)+"%");
        }

    }

    public void actualizar()
    {
        float s = 1.0f;


        for(int i=0; i<topics.size(); i++)
        {

            s = (sDB.getStats(i+1)/100) * 25;

            if(s==0) s = 1;
            ScaleAnimation scaleAnim = new ScaleAnimation(1.0f, s, 1.0f, 1.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f,
                    Animation.RELATIVE_TO_SELF, 0.0f);
            scaleAnim.setFillAfter(true);
            scaleAnim.setInterpolator(new LinearInterpolator());
            scaleAnim.setDuration(2000);
            topics.get(i).startAnimation(scaleAnim);

            int originalPos[] = new int[2];
            stopics.get(i).getLocationOnScreen(originalPos);



            CuentaAtras c = new CuentaAtras(2000, 100, stopics.get(i), sDB.getStats(i+1));

            c.start();

        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }

}
