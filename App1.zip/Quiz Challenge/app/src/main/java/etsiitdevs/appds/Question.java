package etsiitdevs.appds;

/**
 * Created by juanpi on 11/05/15.
 */
public class Question
{
    private String question;

    public Question(String q)
    {
        question = q;
    }


    public String getQuestion()
    {
        return question;
    }
}
