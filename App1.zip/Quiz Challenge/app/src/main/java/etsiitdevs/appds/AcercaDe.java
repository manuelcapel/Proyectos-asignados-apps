package etsiitdevs.appds;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

/**
 * Created by fura on 15/05/15.
 */



public class AcercaDe extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acerca_de);
    }



}
