package etsiitdevs.appds;

import android.content.Context;

import java.sql.SQLException;

/**
 * Created by juanpi on 12/05/15.
 */
public class StatsDB
{
    public DBHelper db;

    public StatsDB(Context c)
    {
        db = DBHelper.getInstance(c);
    }

    public float getStats(int id)
    {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        int[] stats = db.getStats(id);
        db.close();

        float res = 1;
        if(stats[1] != 0)
            res = (stats[0]/(stats[1]*1.0f))*100;

        return res;
    }


    public void updateStats(int[] acertadas, int n)
    {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        db.updateStats(acertadas, n);
        db.close();
    }


    public void reiniciarStats()
    {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        db.reiniciarStats();
        db.close();
    }
}
