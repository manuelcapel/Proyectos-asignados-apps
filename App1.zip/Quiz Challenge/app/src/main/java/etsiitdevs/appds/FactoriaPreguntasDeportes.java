package etsiitdevs.appds;

import android.content.Context;

import java.sql.SQLException;

/**
 * Created by juanpi on 11/05/15.
 */
public class FactoriaPreguntasDeportes extends FactoriaPreguntas {

    private DBHelper db;

    private static final Topic t = Topic.Deportes;

    public FactoriaPreguntasDeportes()
    {
        db = DBHelper.getInstance();
    }

    @Override
    public QuizDeportes getQuestion() {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        QuizDeportes q = (QuizDeportes) db.getQuiz(Topic.getTopic(t));
        db.close();
        return q;
    }
}