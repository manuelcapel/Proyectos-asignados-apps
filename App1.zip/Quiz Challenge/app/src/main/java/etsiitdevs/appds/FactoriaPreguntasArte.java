package etsiitdevs.appds;

import android.content.Context;

import java.sql.SQLException;

/**
 * Created by juanpi on 11/05/15.
 */
public class FactoriaPreguntasArte extends FactoriaPreguntas {

    private DBHelper db;

    private static final Topic t = Topic.Arte;

    public FactoriaPreguntasArte()
    {
        db = DBHelper.getInstance();
    }

    @Override
    public QuizArte getQuestion()
    {
        try {
            db.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        QuizArte q = (QuizArte) db.getQuiz(Topic.getTopic(t));
        db.close();
        return q;
    }
}
