package etsiitdevs.appds;

/**
 * Created by juanpi on 13/05/15.
 */
public class QuizArte extends Quiz{

    private Question question;
    private Answers answers;
    private Topic topic;

    public QuizArte(String q, String a1, String a2, String a3, String a4, int c, Topic t)
    {
        question = new Question(q);
        answers = new Answers(a1, a2, a3, a4, c);
        topic = t;
    }

    @Override
    public Question getQuestion()
    {
        return question;
    }

    @Override
    public Answers getAnswers()
    {
        return answers;
    }

    @Override
    public Topic getTopic()
    {
        return topic;
    }

    @Override
    public int getCorrect()
    {
        return answers.getCorrect();
    }
}
