package etsiitdevs.appds;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.preference.SwitchPreference;
import android.text.TextUtils;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;


import java.util.List;

/**
 * A {@link PreferenceActivity} that presents a set of application settings. On
 * handset devices, settings are presented as a single list. On tablets,
 * settings are split by category, with category headers shown to the left of
 * the list of settings.
 * <p/>
 * See <a href="http://developer.android.com/design/patterns/settings.html">
 * Android Design: Settings</a> for design guidelines and the <a
 * href="http://developer.android.com/guide/topics/ui/settings.html">Settings
 * API Guide</a> for more information on developing a Settings UI.
 */
public class AjustesActivity extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener{

    SwitchPreference preference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        addPreferencesFromResource(R.xml.ajustes);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPref, String key) {
        if (key.equals("pref_usuario")) {
            Preference connectionPref = findPreference(key);
            connectionPref.setSummary(sharedPref.getString(key, ""));

        }

        if (key.equals("pref_sonido")) {
            final CheckBoxPreference checkBox = (CheckBoxPreference)findPreference("pref_sonido");
            AudioManager amanager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

            if (checkBox.isChecked())
                amanager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
            else
                amanager.setStreamVolume(AudioManager.STREAM_MUSIC, 12, AudioManager.FLAG_SHOW_UI);
        }


        if (key.equals("pref_resetStats")) {
            System.out.println("hola");
            StatsDB st = new StatsDB(this);
            st.reiniciarStats();

            preference = (SwitchPreference)findPreference("pref_resetStats");
            preference.setEnabled(false);
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                public void run() {
                    preference.setChecked(false);
                    preference.setEnabled(true);
                }
            }, 1000);

            //SharedPreferences.Editor editor = root.
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

}
